<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = 'ACqhVDBCkRVlPTMkNeTqs2YdOxIaNT0llocalhost';
$CFG->bootstraphash = '4ebc450666a57b416dd19bd57cab940f';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
