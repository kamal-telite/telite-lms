--
-- PostgreSQL database cluster dump
--

\restrict UbGstLbLu0myexQetga4d03Kw7MlYiX7HboaZjhbibld9tdSVmrcTwhYk1NkjtY

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE moodleuser;
ALTER ROLE moodleuser WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:HE6i9V+K8qGKZLWLMFeYFQ==$64dOFrF4Vy+8z5LUnq8kfo7nTHoJR4ndTvjTkyH5UQ8=:mbrpcW1+p+a+MwkPK/4IPitG9Csmu/FQ6l3rYUa9Oaw=';
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:APIdkI1J+kR6ZQGICao0oQ==$UxsDvrizFJtL0X9Xsxvn37vXTL+er0ySyFWIOr36Nqw=:UOJnRMGQLIJaYlFECr0ccT+eH3rkSeE/mj9Embv4n7k=';
CREATE ROLE telite_app;
ALTER ROLE telite_app WITH NOSUPERUSER NOINHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:dsod8oMV+mIOmwO2eyhYvw==$I7nC7s7r/9qM2TogT11pNeDJp43ehIOvRg/pF42csYo=:fZalsi+saoDtHtPhZqc8b3Oxg89oHFVK12NvuMjwnTg=';






\unrestrict UbGstLbLu0myexQetga4d03Kw7MlYiX7HboaZjhbibld9tdSVmrcTwhYk1NkjtY

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict pY5cYYDlgtfrB7SCgX4MochsSTLZom5tPbXJf9m4vHGm7BIwTfX9iFOoSvjBwwG

-- Dumped from database version 14.22 (Debian 14.22-1.pgdg13+1)
-- Dumped by pg_dump version 14.22 (Debian 14.22-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict pY5cYYDlgtfrB7SCgX4MochsSTLZom5tPbXJf9m4vHGm7BIwTfX9iFOoSvjBwwG

--
-- Database "moodle" dump
--

--
-- PostgreSQL database dump
--

\restrict yavviIiexixK5E1y4L6V23itJh3RxTdhf0v3ueU2YsyJhf6tcFj1WKw2oynYErp

-- Dumped from database version 14.22 (Debian 14.22-1.pgdg13+1)
-- Dumped by pg_dump version 14.22 (Debian 14.22-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: moodle; Type: DATABASE; Schema: -; Owner: moodleuser
--

CREATE DATABASE moodle WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE moodle OWNER TO moodleuser;

\unrestrict yavviIiexixK5E1y4L6V23itJh3RxTdhf0v3ueU2YsyJhf6tcFj1WKw2oynYErp
\connect moodle
\restrict yavviIiexixK5E1y4L6V23itJh3RxTdhf0v3ueU2YsyJhf6tcFj1WKw2oynYErp

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE moodle; Type: ACL; Schema: -; Owner: moodleuser
--

REVOKE CONNECT,TEMPORARY ON DATABASE moodle FROM PUBLIC;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO moodleuser;


--
-- PostgreSQL database dump complete
--

\unrestrict yavviIiexixK5E1y4L6V23itJh3RxTdhf0v3ueU2YsyJhf6tcFj1WKw2oynYErp

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict Ns5Km4fWDe0qWkn2LCyLXaGjHYrZXtOX4VVDsDwBVUWAoOEpAOED3pfBUf6qAa7

-- Dumped from database version 14.22 (Debian 14.22-1.pgdg13+1)
-- Dumped by pg_dump version 14.22 (Debian 14.22-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict Ns5Km4fWDe0qWkn2LCyLXaGjHYrZXtOX4VVDsDwBVUWAoOEpAOED3pfBUf6qAa7

--
-- Database "telite_backend" dump
--

--
-- PostgreSQL database dump
--

\restrict 0oecDhTThbgAG6NMz5fHYH6r7kh2ajFeT5NoosccTwtU1UjiQOOt8bDbvacrI3J

-- Dumped from database version 14.22 (Debian 14.22-1.pgdg13+1)
-- Dumped by pg_dump version 14.22 (Debian 14.22-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: telite_backend; Type: DATABASE; Schema: -; Owner: telite_app
--

CREATE DATABASE telite_backend WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE telite_backend OWNER TO telite_app;

\unrestrict 0oecDhTThbgAG6NMz5fHYH6r7kh2ajFeT5NoosccTwtU1UjiQOOt8bDbvacrI3J
\connect telite_backend
\restrict 0oecDhTThbgAG6NMz5fHYH6r7kh2ajFeT5NoosccTwtU1UjiQOOt8bDbvacrI3J

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_log (
    id integer NOT NULL,
    user_id character varying(50),
    category_slug character varying(100),
    icon character varying(50) NOT NULL,
    accent character varying(20) NOT NULL,
    message text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    org_id integer DEFAULT 1 NOT NULL
);

ALTER TABLE ONLY public.activity_log FORCE ROW LEVEL SECURITY;


ALTER TABLE public.activity_log OWNER TO postgres;

--
-- Name: activity_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activity_log_id_seq OWNER TO postgres;

--
-- Name: activity_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_log_id_seq OWNED BY public.activity_log.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: allowed_domains; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.allowed_domains (
    domain character varying NOT NULL,
    label character varying NOT NULL,
    added_by character varying,
    org_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.allowed_domains OWNER TO postgres;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    actor_user_id character varying(50),
    actor_name character varying(255) NOT NULL,
    action character varying(100) NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id character varying(50) NOT NULL,
    message text NOT NULL,
    accent character varying(20) DEFAULT '#2563EB'::character varying NOT NULL,
    result character varying(20) DEFAULT 'success'::character varying NOT NULL,
    severity character varying(20),
    ip_address character varying(50),
    metadata_json text,
    org_id integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);

ALTER TABLE ONLY public.audit_log FORCE ROW LEVEL SECURITY;


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_log_id_seq OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: auth_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_sessions (
    id character varying(50) NOT NULL,
    user_id character varying(50) NOT NULL,
    refresh_token text NOT NULL,
    expires_at character varying(20) NOT NULL,
    revoked_at character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    org_id integer DEFAULT 1 NOT NULL,
    user_agent text,
    ip_address character varying(50)
);

ALTER TABLE ONLY public.auth_sessions FORCE ROW LEVEL SECURITY;


ALTER TABLE public.auth_sessions OWNER TO postgres;

--
-- Name: builder_activity_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.builder_activity_log (
    id integer NOT NULL,
    course_id character varying(50) NOT NULL,
    user_id character varying(50) NOT NULL,
    action character varying(100) NOT NULL,
    payload text,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.builder_activity_log OWNER TO postgres;

--
-- Name: builder_activity_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.builder_activity_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.builder_activity_log_id_seq OWNER TO postgres;

--
-- Name: builder_activity_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.builder_activity_log_id_seq OWNED BY public.builder_activity_log.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    accent_color character varying(20) DEFAULT '#2563EB'::character varying NOT NULL,
    admin_user_id character varying(50),
    planned_courses integer DEFAULT 0 NOT NULL,
    avg_pal_target double precision DEFAULT '0'::double precision NOT NULL,
    moodle_category_id integer,
    org_type character varying(50) DEFAULT 'college'::character varying NOT NULL,
    archived_at character varying(20),
    organization_id integer,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);

ALTER TABLE ONLY public.categories FORCE ROW LEVEL SECURITY;


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: certificates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.certificates (
    id character varying(50) NOT NULL,
    user_id character varying(50) NOT NULL,
    course_id character varying(50) NOT NULL,
    issued_at timestamp with time zone NOT NULL,
    pdf_s3_key character varying(255) NOT NULL,
    certificate_hash character varying(255) NOT NULL,
    verification_token character varying(255) NOT NULL,
    qr_code_url text,
    issued_version integer NOT NULL,
    metadata_json json,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.certificates OWNER TO postgres;

--
-- Name: COLUMN certificates.id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.certificates.id IS 'Public unique ID for verification';


--
-- Name: COLUMN certificates.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.certificates.org_id IS 'Tenant organisation ID — used by RLS policies';


--
-- Name: course_edit_locks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.course_edit_locks (
    course_id character varying(50) NOT NULL,
    user_id character varying(50) NOT NULL,
    locked_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    org_id integer NOT NULL
);


ALTER TABLE public.course_edit_locks OWNER TO postgres;

--
-- Name: course_modules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.course_modules (
    id integer NOT NULL,
    course_id character varying(50) NOT NULL,
    moodle_cmid integer,
    section integer NOT NULL,
    title character varying(255) NOT NULL,
    module_type character varying(50) NOT NULL,
    sort_order integer NOT NULL,
    content_url text,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    section_id integer,
    status character varying(20) DEFAULT 'published'::character varying NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by character varying(50)
);


ALTER TABLE public.course_modules OWNER TO postgres;

--
-- Name: COLUMN course_modules.moodle_cmid; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.course_modules.moodle_cmid IS 'Moodle Course Module ID';


--
-- Name: COLUMN course_modules.module_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.course_modules.module_type IS 'e.g. page, url, quiz, scorm';


--
-- Name: COLUMN course_modules.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.course_modules.org_id IS 'Tenant organisation ID — used by RLS policies';


--
-- Name: course_modules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.course_modules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_modules_id_seq OWNER TO postgres;

--
-- Name: course_modules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.course_modules_id_seq OWNED BY public.course_modules.id;


--
-- Name: course_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.course_progress (
    id integer NOT NULL,
    user_id character varying(50) NOT NULL,
    course_id character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    completion_percentage double precision NOT NULL,
    time_spent_seconds integer NOT NULL,
    started_at timestamp with time zone,
    last_viewed_at timestamp with time zone,
    completed_at timestamp with time zone,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.course_progress OWNER TO postgres;

--
-- Name: COLUMN course_progress.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.course_progress.status IS 'not_started, in_progress, completed';


--
-- Name: COLUMN course_progress.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.course_progress.org_id IS 'Tenant organisation ID — used by RLS policies';


--
-- Name: course_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.course_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_progress_id_seq OWNER TO postgres;

--
-- Name: course_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.course_progress_id_seq OWNED BY public.course_progress.id;


--
-- Name: course_reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.course_reviews (
    id integer NOT NULL,
    course_id character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    from_status character varying(20),
    to_status character varying(20) NOT NULL,
    notes text,
    reviewed_by character varying(50),
    reviewed_at timestamp with time zone NOT NULL,
    org_id integer NOT NULL
);


ALTER TABLE public.course_reviews OWNER TO postgres;

--
-- Name: COLUMN course_reviews.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.course_reviews.org_id IS 'Tenant organisation ID - used by RLS policies';


--
-- Name: course_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.course_reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_reviews_id_seq OWNER TO postgres;

--
-- Name: course_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.course_reviews_id_seq OWNED BY public.course_reviews.id;


--
-- Name: course_sections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.course_sections (
    id integer NOT NULL,
    course_id character varying(50) NOT NULL,
    org_id integer NOT NULL,
    title character varying(255) NOT NULL,
    sort_order integer NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by character varying(50)
);


ALTER TABLE public.course_sections OWNER TO postgres;

--
-- Name: course_sections_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.course_sections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_sections_id_seq OWNER TO postgres;

--
-- Name: course_sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.course_sections_id_seq OWNED BY public.course_sections.id;


--
-- Name: course_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.course_versions (
    id character varying(50) NOT NULL,
    course_id character varying(50) NOT NULL,
    org_id integer NOT NULL,
    version_number integer NOT NULL,
    status character varying(20) NOT NULL,
    parent_version_id character varying(50),
    created_by character varying(50) NOT NULL,
    published_at timestamp with time zone,
    published_by character varying(50),
    created_at timestamp with time zone
);


ALTER TABLE public.course_versions OWNER TO postgres;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courses (
    id character varying(50) NOT NULL,
    moodle_course_id integer,
    category_slug character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    tier character varying(50) DEFAULT 'Basic'::character varying NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    module_count integer DEFAULT 0 NOT NULL,
    modules_json text DEFAULT '[]'::text NOT NULL,
    lessons_count integer DEFAULT 0 NOT NULL,
    hours double precision DEFAULT '0'::double precision NOT NULL,
    enrolled_count integer DEFAULT 0 NOT NULL,
    completion_rate double precision DEFAULT '0'::double precision NOT NULL,
    completion_count integer DEFAULT 0 NOT NULL,
    avg_quiz_score double precision DEFAULT '0'::double precision NOT NULL,
    prerequisite_course_id character varying(50),
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    price_paise integer DEFAULT 0 NOT NULL
);

ALTER TABLE ONLY public.courses FORCE ROW LEVEL SECURITY;


ALTER TABLE public.courses OWNER TO postgres;

--
-- Name: enrollment_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.enrollment_requests (
    id character varying(50) NOT NULL,
    full_name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    category_slug character varying(100) NOT NULL,
    request_type character varying(50) NOT NULL,
    company_domain character varying(255),
    domain_verified boolean DEFAULT false NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    requested_at character varying(20) NOT NULL,
    reviewed_by character varying(50),
    reviewed_at character varying(20),
    rejection_reason text,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);

ALTER TABLE ONLY public.enrollment_requests FORCE ROW LEVEL SECURITY;


ALTER TABLE public.enrollment_requests OWNER TO postgres;

--
-- Name: grading_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grading_events (
    id integer NOT NULL,
    org_id integer NOT NULL,
    attempt_id integer NOT NULL,
    grader_id character varying(50) NOT NULL,
    previous_score double precision,
    new_score double precision,
    action character varying(50) NOT NULL,
    "timestamp" timestamp with time zone
);


ALTER TABLE public.grading_events OWNER TO postgres;

--
-- Name: grading_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grading_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grading_events_id_seq OWNER TO postgres;

--
-- Name: grading_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grading_events_id_seq OWNED BY public.grading_events.id;


--
-- Name: grading_rubrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grading_rubrics (
    id integer NOT NULL,
    org_id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.grading_rubrics OWNER TO postgres;

--
-- Name: grading_rubrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grading_rubrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grading_rubrics_id_seq OWNER TO postgres;

--
-- Name: grading_rubrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grading_rubrics_id_seq OWNED BY public.grading_rubrics.id;


--
-- Name: interactive_tracking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.interactive_tracking (
    id integer NOT NULL,
    attempt_id integer NOT NULL,
    protocol character varying(20) NOT NULL,
    element character varying(255) NOT NULL,
    value text,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.interactive_tracking OWNER TO postgres;

--
-- Name: COLUMN interactive_tracking.protocol; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.interactive_tracking.protocol IS 'scorm_12, scorm_2004, xapi';


--
-- Name: COLUMN interactive_tracking.element; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.interactive_tracking.element IS 'e.g. cmi.suspend_data';


--
-- Name: COLUMN interactive_tracking.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.interactive_tracking.org_id IS 'Tenant organisation ID — used by RLS policies';


--
-- Name: interactive_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.interactive_tracking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.interactive_tracking_id_seq OWNER TO postgres;

--
-- Name: interactive_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.interactive_tracking_id_seq OWNED BY public.interactive_tracking.id;


--
-- Name: learner_activity_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.learner_activity_log (
    id integer NOT NULL,
    user_id character varying(50) NOT NULL,
    action character varying(100) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(50) NOT NULL,
    details character varying(500),
    ip_address character varying(45),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    org_id integer NOT NULL
);


ALTER TABLE public.learner_activity_log OWNER TO postgres;

--
-- Name: COLUMN learner_activity_log.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.learner_activity_log.org_id IS 'Tenant organisation ID — used by RLS policies';


--
-- Name: learner_activity_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.learner_activity_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.learner_activity_log_id_seq OWNER TO postgres;

--
-- Name: learner_activity_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.learner_activity_log_id_seq OWNED BY public.learner_activity_log.id;


--
-- Name: learner_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.learner_events (
    id integer NOT NULL,
    user_id character varying(50) NOT NULL,
    course_id character varying(50),
    module_id integer,
    block_id integer,
    event_type character varying(50) NOT NULL,
    schema_version character varying(10) NOT NULL,
    payload_json json NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    org_id integer NOT NULL
);


ALTER TABLE public.learner_events OWNER TO postgres;

--
-- Name: COLUMN learner_events.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.learner_events.org_id IS 'Tenant organisation ID — used by RLS policies';


--
-- Name: learner_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.learner_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.learner_events_id_seq OWNER TO postgres;

--
-- Name: learner_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.learner_events_id_seq OWNED BY public.learner_events.id;


--
-- Name: learning_path_courses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.learning_path_courses (
    path_id integer NOT NULL,
    course_id character varying(50) NOT NULL,
    org_id integer NOT NULL,
    sort_order integer NOT NULL
);


ALTER TABLE public.learning_path_courses OWNER TO postgres;

--
-- Name: learning_path_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.learning_path_progress (
    id integer NOT NULL,
    user_id character varying(50) NOT NULL,
    path_id integer NOT NULL,
    status character varying(20) NOT NULL,
    completion_percentage double precision NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.learning_path_progress OWNER TO postgres;

--
-- Name: COLUMN learning_path_progress.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.learning_path_progress.status IS 'not_started, in_progress, completed';


--
-- Name: COLUMN learning_path_progress.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.learning_path_progress.org_id IS 'Tenant organisation ID — used by RLS policies';


--
-- Name: learning_path_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.learning_path_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.learning_path_progress_id_seq OWNER TO postgres;

--
-- Name: learning_path_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.learning_path_progress_id_seq OWNED BY public.learning_path_progress.id;


--
-- Name: learning_paths; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.learning_paths (
    id integer NOT NULL,
    org_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    settings text DEFAULT '{}'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    deleted_by character varying(50)
);


ALTER TABLE public.learning_paths OWNER TO postgres;

--
-- Name: learning_paths_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.learning_paths_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.learning_paths_id_seq OWNER TO postgres;

--
-- Name: learning_paths_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.learning_paths_id_seq OWNED BY public.learning_paths.id;


--
-- Name: lesson_block_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lesson_block_progress (
    id integer NOT NULL,
    user_id character varying(50) NOT NULL,
    module_id integer NOT NULL,
    block_id integer NOT NULL,
    status character varying(20) NOT NULL,
    video_position_seconds integer NOT NULL,
    completion_percentage double precision NOT NULL,
    time_spent_seconds integer NOT NULL,
    last_viewed_at timestamp with time zone,
    completed_at timestamp with time zone,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.lesson_block_progress OWNER TO postgres;

--
-- Name: COLUMN lesson_block_progress.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.lesson_block_progress.status IS 'not_started, completed';


--
-- Name: COLUMN lesson_block_progress.video_position_seconds; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.lesson_block_progress.video_position_seconds IS 'Resume position for video blocks';


--
-- Name: COLUMN lesson_block_progress.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.lesson_block_progress.org_id IS 'Tenant organisation ID — used by RLS policies';


--
-- Name: lesson_block_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lesson_block_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lesson_block_progress_id_seq OWNER TO postgres;

--
-- Name: lesson_block_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lesson_block_progress_id_seq OWNED BY public.lesson_block_progress.id;


--
-- Name: lesson_blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lesson_blocks (
    id integer NOT NULL,
    module_id integer NOT NULL,
    org_id integer NOT NULL,
    block_type character varying(50) NOT NULL,
    content text,
    media_asset_id integer,
    sort_order integer NOT NULL,
    metadata_json json,
    deleted_at timestamp with time zone,
    deleted_by character varying(50)
);


ALTER TABLE public.lesson_blocks OWNER TO postgres;

--
-- Name: lesson_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lesson_blocks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lesson_blocks_id_seq OWNER TO postgres;

--
-- Name: lesson_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lesson_blocks_id_seq OWNED BY public.lesson_blocks.id;


--
-- Name: media_assets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media_assets (
    id integer NOT NULL,
    org_id integer NOT NULL,
    uploaded_by character varying(50) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_type character varying(50) NOT NULL,
    file_size integer NOT NULL,
    storage_key character varying(255) NOT NULL,
    storage_provider character varying(50) NOT NULL,
    url text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    deleted_by character varying(50),
    folder character varying(120),
    tags_json text,
    metadata_json text
);


ALTER TABLE public.media_assets OWNER TO postgres;

--
-- Name: media_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.media_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.media_assets_id_seq OWNER TO postgres;

--
-- Name: media_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.media_assets_id_seq OWNED BY public.media_assets.id;


--
-- Name: memberships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.memberships (
    id integer NOT NULL,
    user_id character varying(50) NOT NULL,
    org_id integer NOT NULL,
    role character varying(50) NOT NULL,
    category_scope character varying(100),
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    granted_by character varying(50),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.memberships OWNER TO postgres;

--
-- Name: memberships_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.memberships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.memberships_id_seq OWNER TO postgres;

--
-- Name: memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.memberships_id_seq OWNED BY public.memberships.id;


--
-- Name: module_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.module_progress (
    id integer NOT NULL,
    user_id character varying(50) NOT NULL,
    module_id integer NOT NULL,
    status character varying(20) NOT NULL,
    score double precision,
    time_spent_seconds integer NOT NULL,
    completed_at timestamp with time zone,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    last_block_id character varying(50),
    started_at timestamp with time zone,
    last_viewed_at timestamp with time zone
);


ALTER TABLE public.module_progress OWNER TO postgres;

--
-- Name: COLUMN module_progress.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.module_progress.status IS 'not_started, in_progress, completed';


--
-- Name: COLUMN module_progress.score; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.module_progress.score IS 'For quizzes/SCORM';


--
-- Name: COLUMN module_progress.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.module_progress.org_id IS 'Tenant organisation ID — used by RLS policies';


--
-- Name: COLUMN module_progress.last_block_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.module_progress.last_block_id IS 'For exact resume position';


--
-- Name: module_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.module_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.module_progress_id_seq OWNER TO postgres;

--
-- Name: module_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.module_progress_id_seq OWNED BY public.module_progress.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    body text NOT NULL,
    type character varying(50) DEFAULT 'info'::character varying NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    metadata_json text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    org_id integer DEFAULT 1 NOT NULL
);

ALTER TABLE ONLY public.notifications FORCE ROW LEVEL SECURITY;


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: org_invitations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_invitations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    email character varying NOT NULL,
    role character varying NOT NULL,
    category_scope character varying,
    token character varying NOT NULL,
    invited_by character varying,
    expires_at character varying NOT NULL,
    accepted_at character varying,
    revoked_at character varying,
    revoked_by character varying,
    revoke_reason character varying,
    resend_count integer DEFAULT 0 NOT NULL,
    last_sent_at character varying,
    last_resent_at character varying,
    delivery_status character varying DEFAULT 'pending'::character varying NOT NULL,
    delivery_error character varying,
    delivery_attempted_at character varying,
    delivered_at character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);

ALTER TABLE ONLY public.org_invitations FORCE ROW LEVEL SECURITY;


ALTER TABLE public.org_invitations OWNER TO postgres;

--
-- Name: org_invitations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.org_invitations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.org_invitations_id_seq OWNER TO postgres;

--
-- Name: org_invitations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.org_invitations_id_seq OWNED BY public.org_invitations.id;


--
-- Name: organization_branding; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organization_branding (
    id integer NOT NULL,
    org_id integer NOT NULL,
    organization_id integer NOT NULL,
    logo_url text,
    favicon_url text,
    login_banner_url text,
    primary_color character varying(20),
    secondary_color character varying(20),
    font_family character varying(100),
    theme_mode character varying(20) DEFAULT 'light'::character varying NOT NULL,
    certificate_template_url text,
    email_template_id character varying(100),
    landing_page_config text,
    terminology_json text,
    seo_title character varying(255),
    seo_description text,
    custom_domain character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    certificate_primary_color character varying(20),
    certificate_signature_url text,
    certificate_qr_layout character varying(20)
);


ALTER TABLE public.organization_branding OWNER TO postgres;

--
-- Name: COLUMN organization_branding.certificate_qr_layout; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.organization_branding.certificate_qr_layout IS 'bottom_left, bottom_right, hidden';


--
-- Name: organization_branding_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organization_branding_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organization_branding_id_seq OWNER TO postgres;

--
-- Name: organization_branding_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organization_branding_id_seq OWNED BY public.organization_branding.id;


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    domain character varying(255) NOT NULL,
    slug character varying(100),
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    moodle_category_id integer,
    moodle_tenant_key character varying(100),
    admin_user_id character varying(50),
    created_by character varying(50),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    favicon_url text,
    login_banner_url text,
    primary_color character varying(20),
    secondary_color character varying(20),
    font_family character varying(100),
    theme_mode character varying(20) DEFAULT 'light'::character varying NOT NULL,
    certificate_template text,
    email_template text,
    custom_domain character varying(255),
    plan character varying(50) DEFAULT 'free'::character varying NOT NULL
);


ALTER TABLE public.organizations OWNER TO postgres;

--
-- Name: organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizations_id_seq OWNER TO postgres;

--
-- Name: organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizations_id_seq OWNED BY public.organizations.id;


--
-- Name: pal_quiz_scores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pal_quiz_scores (
    id integer NOT NULL,
    org_id integer NOT NULL,
    enrollment_number character varying(50) NOT NULL,
    user_id character varying(50),
    course_id integer NOT NULL,
    course_name character varying(255),
    quiz_id integer,
    quiz_name character varying(255),
    topic character varying(100),
    score double precision NOT NULL,
    max_score double precision DEFAULT '100'::double precision NOT NULL,
    percentage double precision,
    branch character varying(100),
    college character varying(255),
    synced_from_moodle integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);

ALTER TABLE ONLY public.pal_quiz_scores FORCE ROW LEVEL SECURITY;


ALTER TABLE public.pal_quiz_scores OWNER TO postgres;

--
-- Name: pal_quiz_scores_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pal_quiz_scores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pal_quiz_scores_id_seq OWNER TO postgres;

--
-- Name: pal_quiz_scores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pal_quiz_scores_id_seq OWNED BY public.pal_quiz_scores.id;


--
-- Name: pal_recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pal_recommendations (
    id integer NOT NULL,
    org_id integer NOT NULL,
    enrollment_number character varying(50) NOT NULL,
    user_id character varying(50),
    level character varying(20) NOT NULL,
    weak_topics text,
    strong_topics text,
    recommended_courses text,
    recommended_resources text,
    avg_score double precision,
    email_sent integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);

ALTER TABLE ONLY public.pal_recommendations FORCE ROW LEVEL SECURITY;


ALTER TABLE public.pal_recommendations OWNER TO postgres;

--
-- Name: pal_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pal_recommendations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pal_recommendations_id_seq OWNER TO postgres;

--
-- Name: pal_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pal_recommendations_id_seq OWNED BY public.pal_recommendations.id;


--
-- Name: pal_topic_performance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pal_topic_performance (
    id integer NOT NULL,
    org_id integer NOT NULL,
    enrollment_number character varying(50) NOT NULL,
    user_id character varying(50),
    topic character varying(100) NOT NULL,
    avg_score double precision,
    attempts integer DEFAULT 1 NOT NULL,
    last_updated character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);

ALTER TABLE ONLY public.pal_topic_performance FORCE ROW LEVEL SECURITY;


ALTER TABLE public.pal_topic_performance OWNER TO postgres;

--
-- Name: pal_topic_performance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pal_topic_performance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pal_topic_performance_id_seq OWNER TO postgres;

--
-- Name: pal_topic_performance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pal_topic_performance_id_seq OWNED BY public.pal_topic_performance.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_tokens (
    id integer NOT NULL,
    user_id character varying(50) NOT NULL,
    token character varying NOT NULL,
    expires_at character varying NOT NULL,
    used_at character varying,
    delivery_status character varying DEFAULT 'pending'::character varying NOT NULL,
    delivery_error character varying,
    delivery_attempted_at character varying,
    delivered_at character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    org_id integer DEFAULT 1 NOT NULL
);

ALTER TABLE ONLY public.password_reset_tokens FORCE ROW LEVEL SECURITY;


ALTER TABLE public.password_reset_tokens OWNER TO postgres;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.password_reset_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.password_reset_tokens_id_seq OWNER TO postgres;

--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.password_reset_tokens_id_seq OWNED BY public.password_reset_tokens.id;


--
-- Name: pending_verifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pending_verifications (
    id character varying NOT NULL,
    email character varying NOT NULL,
    full_name character varying NOT NULL,
    password_hash character varying NOT NULL,
    role_name character varying NOT NULL,
    domain_type character varying NOT NULL,
    organization_name character varying NOT NULL,
    organization_id integer NOT NULL,
    phone character varying,
    employee_id character varying,
    department character varying,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    rejection_reason character varying,
    reviewed_by character varying,
    reviewed_at character varying,
    moodle_id integer,
    program character varying,
    branch character varying,
    id_number character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    org_id integer NOT NULL
);


ALTER TABLE public.pending_verifications OWNER TO postgres;

--
-- Name: platform_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.platform_settings (
    id integer NOT NULL,
    setting_key character varying NOT NULL,
    setting_value_json character varying NOT NULL,
    updated_by character varying,
    updated_at character varying NOT NULL
);


ALTER TABLE public.platform_settings OWNER TO postgres;

--
-- Name: platform_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.platform_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.platform_settings_id_seq OWNER TO postgres;

--
-- Name: platform_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.platform_settings_id_seq OWNED BY public.platform_settings.id;


--
-- Name: question_banks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.question_banks (
    id integer NOT NULL,
    org_id integer NOT NULL,
    name character varying(255) NOT NULL,
    visibility character varying(50) NOT NULL,
    created_at timestamp with time zone,
    deleted_at timestamp with time zone,
    deleted_by character varying(50)
);


ALTER TABLE public.question_banks OWNER TO postgres;

--
-- Name: question_banks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.question_banks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.question_banks_id_seq OWNER TO postgres;

--
-- Name: question_banks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.question_banks_id_seq OWNED BY public.question_banks.id;


--
-- Name: question_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.question_versions (
    id integer NOT NULL,
    question_id integer NOT NULL,
    version_number integer NOT NULL,
    question_type character varying(50) NOT NULL,
    question_text text NOT NULL,
    options_json json,
    correct_answer_json json,
    points integer NOT NULL,
    metadata_json json,
    created_at timestamp with time zone,
    org_id integer NOT NULL
);


ALTER TABLE public.question_versions OWNER TO postgres;

--
-- Name: question_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.question_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.question_versions_id_seq OWNER TO postgres;

--
-- Name: question_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.question_versions_id_seq OWNED BY public.question_versions.id;


--
-- Name: questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.questions (
    id integer NOT NULL,
    bank_id integer NOT NULL,
    org_id integer NOT NULL,
    current_version_id integer,
    created_at timestamp with time zone,
    deleted_at timestamp with time zone
);


ALTER TABLE public.questions OWNER TO postgres;

--
-- Name: questions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.questions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_id_seq OWNER TO postgres;

--
-- Name: questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.questions_id_seq OWNED BY public.questions.id;


--
-- Name: quiz_answers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_answers (
    id integer NOT NULL,
    attempt_id integer NOT NULL,
    question_version_id integer NOT NULL,
    response_json json,
    is_correct integer,
    points_awarded double precision,
    instructor_feedback text,
    org_id integer NOT NULL
);


ALTER TABLE public.quiz_answers OWNER TO postgres;

--
-- Name: quiz_answers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quiz_answers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quiz_answers_id_seq OWNER TO postgres;

--
-- Name: quiz_answers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quiz_answers_id_seq OWNED BY public.quiz_answers.id;


--
-- Name: quiz_attempt_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_attempt_events (
    id integer NOT NULL,
    attempt_id integer NOT NULL,
    event_type character varying(50) NOT NULL,
    event_timestamp timestamp with time zone NOT NULL,
    metadata_json json,
    org_id integer NOT NULL
);


ALTER TABLE public.quiz_attempt_events OWNER TO postgres;

--
-- Name: quiz_attempt_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quiz_attempt_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quiz_attempt_events_id_seq OWNER TO postgres;

--
-- Name: quiz_attempt_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quiz_attempt_events_id_seq OWNED BY public.quiz_attempt_events.id;


--
-- Name: quiz_attempt_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_attempt_questions (
    id integer NOT NULL,
    attempt_id integer NOT NULL,
    question_version_id integer NOT NULL,
    display_order integer NOT NULL,
    org_id integer NOT NULL
);


ALTER TABLE public.quiz_attempt_questions OWNER TO postgres;

--
-- Name: quiz_attempt_questions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quiz_attempt_questions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quiz_attempt_questions_id_seq OWNER TO postgres;

--
-- Name: quiz_attempt_questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quiz_attempt_questions_id_seq OWNED BY public.quiz_attempt_questions.id;


--
-- Name: quiz_attempts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_attempts (
    id integer NOT NULL,
    org_id integer NOT NULL,
    quiz_id integer NOT NULL,
    user_id character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    started_at timestamp with time zone,
    submitted_at timestamp with time zone,
    total_score double precision,
    passed integer,
    ip_address character varying(255),
    user_agent character varying(500),
    tab_switch_count integer
);


ALTER TABLE public.quiz_attempts OWNER TO postgres;

--
-- Name: quiz_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quiz_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quiz_attempts_id_seq OWNER TO postgres;

--
-- Name: quiz_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quiz_attempts_id_seq OWNED BY public.quiz_attempts.id;


--
-- Name: quiz_definitions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_definitions (
    id integer NOT NULL,
    org_id integer NOT NULL,
    module_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    passing_score integer,
    created_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    deleted_by character varying(50)
);


ALTER TABLE public.quiz_definitions OWNER TO postgres;

--
-- Name: quiz_definitions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quiz_definitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quiz_definitions_id_seq OWNER TO postgres;

--
-- Name: quiz_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quiz_definitions_id_seq OWNED BY public.quiz_definitions.id;


--
-- Name: quiz_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_questions (
    id integer NOT NULL,
    quiz_id integer NOT NULL,
    org_id integer NOT NULL,
    question_type character varying(50) NOT NULL,
    question_text text NOT NULL,
    options_json json,
    correct_answer_json json,
    sort_order integer NOT NULL,
    points integer NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by character varying(50)
);


ALTER TABLE public.quiz_questions OWNER TO postgres;

--
-- Name: quiz_questions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quiz_questions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quiz_questions_id_seq OWNER TO postgres;

--
-- Name: quiz_questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quiz_questions_id_seq OWNED BY public.quiz_questions.id;


--
-- Name: quiz_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_settings (
    id integer NOT NULL,
    quiz_id integer NOT NULL,
    time_limit integer,
    passing_score integer,
    attempt_limit integer,
    show_answers character varying(50),
    show_score character varying(50),
    shuffle_questions integer,
    shuffle_options integer,
    cooldown_minutes integer,
    review_mode character varying(50),
    created_at timestamp with time zone,
    org_id integer NOT NULL
);


ALTER TABLE public.quiz_settings OWNER TO postgres;

--
-- Name: quiz_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quiz_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quiz_settings_id_seq OWNER TO postgres;

--
-- Name: quiz_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quiz_settings_id_seq OWNED BY public.quiz_settings.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permissions (
    id integer NOT NULL,
    org_id integer NOT NULL,
    role character varying(50) NOT NULL,
    permission_key character varying(120) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.role_permissions OWNER TO postgres;

--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.role_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_permissions_id_seq OWNER TO postgres;

--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- Name: rubric_criteria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rubric_criteria (
    id integer NOT NULL,
    rubric_id integer NOT NULL,
    name character varying(255) NOT NULL,
    max_points double precision NOT NULL,
    org_id integer NOT NULL
);


ALTER TABLE public.rubric_criteria OWNER TO postgres;

--
-- Name: rubric_criteria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rubric_criteria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rubric_criteria_id_seq OWNER TO postgres;

--
-- Name: rubric_criteria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rubric_criteria_id_seq OWNED BY public.rubric_criteria.id;


--
-- Name: task_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_assignments (
    id integer NOT NULL,
    task_id character varying(50) NOT NULL,
    learner_id character varying(50) NOT NULL,
    status character varying(30) DEFAULT 'assigned'::character varying NOT NULL,
    assigned_at timestamp with time zone,
    started_at timestamp with time zone,
    submitted_at timestamp with time zone,
    completed_at timestamp with time zone,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.task_assignments OWNER TO postgres;

--
-- Name: COLUMN task_assignments.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.task_assignments.org_id IS 'Tenant organisation ID - used by RLS policies';


--
-- Name: task_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_assignments_id_seq OWNER TO postgres;

--
-- Name: task_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_assignments_id_seq OWNED BY public.task_assignments.id;


--
-- Name: task_reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_reviews (
    id integer NOT NULL,
    submission_id integer NOT NULL,
    review_status character varying(30) NOT NULL,
    review_notes text,
    reviewed_by character varying(50),
    reviewed_at timestamp with time zone,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.task_reviews OWNER TO postgres;

--
-- Name: COLUMN task_reviews.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.task_reviews.org_id IS 'Tenant organisation ID - used by RLS policies';


--
-- Name: task_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_reviews_id_seq OWNER TO postgres;

--
-- Name: task_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_reviews_id_seq OWNED BY public.task_reviews.id;


--
-- Name: task_submissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_submissions (
    id integer NOT NULL,
    assignment_id integer NOT NULL,
    submission_notes text,
    attachment_url text,
    github_url text,
    external_url text,
    submitted_at timestamp with time zone,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.task_submissions OWNER TO postgres;

--
-- Name: COLUMN task_submissions.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.task_submissions.org_id IS 'Tenant organisation ID - used by RLS policies';


--
-- Name: task_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_submissions_id_seq OWNER TO postgres;

--
-- Name: task_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_submissions_id_seq OWNED BY public.task_submissions.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    assigned_label character varying(255) NOT NULL,
    assigned_to_user_id character varying(50),
    assignment_scope character varying(50) DEFAULT 'individual'::character varying NOT NULL,
    category_slug character varying(100) NOT NULL,
    due_at character varying(20),
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    assigned_by character varying(50),
    notes text,
    is_cross_category boolean DEFAULT false NOT NULL,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);

ALTER TABLE ONLY public.tasks FORCE ROW LEVEL SECURITY;


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying(50) NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    role character varying(50) NOT NULL,
    category_scope character varying(100),
    password_hash text NOT NULL,
    avatar_initials character varying(5) NOT NULL,
    gradient_start character varying(50) NOT NULL,
    gradient_end character varying(50) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_platform_admin boolean DEFAULT false NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    pal_score double precision DEFAULT '0'::double precision NOT NULL,
    pal_completion_pct double precision DEFAULT '0'::double precision NOT NULL,
    pal_quiz_avg double precision DEFAULT '0'::double precision NOT NULL,
    pal_time_spent_hours double precision DEFAULT '0'::double precision NOT NULL,
    pal_task_completion_pct double precision DEFAULT '0'::double precision NOT NULL,
    streak_days integer DEFAULT 0 NOT NULL,
    courses_completed integer DEFAULT 0 NOT NULL,
    total_courses integer DEFAULT 0 NOT NULL,
    cohort_rank integer,
    enrollment_type character varying(50),
    current_course_id character varying(50),
    course_progress_json text DEFAULT '[]'::text NOT NULL,
    program character varying(100),
    branch character varying(100),
    id_number character varying(50),
    moodle_id integer,
    last_login character varying(20),
    invited_via character varying(50),
    organization_id integer,
    org_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);

ALTER TABLE ONLY public.users FORCE ROW LEVEL SECURITY;


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: activity_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_log ALTER COLUMN id SET DEFAULT nextval('public.activity_log_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: builder_activity_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.builder_activity_log ALTER COLUMN id SET DEFAULT nextval('public.builder_activity_log_id_seq'::regclass);


--
-- Name: course_modules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_modules ALTER COLUMN id SET DEFAULT nextval('public.course_modules_id_seq'::regclass);


--
-- Name: course_progress id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_progress ALTER COLUMN id SET DEFAULT nextval('public.course_progress_id_seq'::regclass);


--
-- Name: course_reviews id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_reviews ALTER COLUMN id SET DEFAULT nextval('public.course_reviews_id_seq'::regclass);


--
-- Name: course_sections id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_sections ALTER COLUMN id SET DEFAULT nextval('public.course_sections_id_seq'::regclass);


--
-- Name: grading_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grading_events ALTER COLUMN id SET DEFAULT nextval('public.grading_events_id_seq'::regclass);


--
-- Name: grading_rubrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grading_rubrics ALTER COLUMN id SET DEFAULT nextval('public.grading_rubrics_id_seq'::regclass);


--
-- Name: interactive_tracking id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interactive_tracking ALTER COLUMN id SET DEFAULT nextval('public.interactive_tracking_id_seq'::regclass);


--
-- Name: learner_activity_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learner_activity_log ALTER COLUMN id SET DEFAULT nextval('public.learner_activity_log_id_seq'::regclass);


--
-- Name: learner_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learner_events ALTER COLUMN id SET DEFAULT nextval('public.learner_events_id_seq'::regclass);


--
-- Name: learning_path_progress id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_path_progress ALTER COLUMN id SET DEFAULT nextval('public.learning_path_progress_id_seq'::regclass);


--
-- Name: learning_paths id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_paths ALTER COLUMN id SET DEFAULT nextval('public.learning_paths_id_seq'::regclass);


--
-- Name: lesson_block_progress id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_block_progress ALTER COLUMN id SET DEFAULT nextval('public.lesson_block_progress_id_seq'::regclass);


--
-- Name: lesson_blocks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_blocks ALTER COLUMN id SET DEFAULT nextval('public.lesson_blocks_id_seq'::regclass);


--
-- Name: media_assets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_assets ALTER COLUMN id SET DEFAULT nextval('public.media_assets_id_seq'::regclass);


--
-- Name: memberships id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memberships ALTER COLUMN id SET DEFAULT nextval('public.memberships_id_seq'::regclass);


--
-- Name: module_progress id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_progress ALTER COLUMN id SET DEFAULT nextval('public.module_progress_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: org_invitations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations ALTER COLUMN id SET DEFAULT nextval('public.org_invitations_id_seq'::regclass);


--
-- Name: organization_branding id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_branding ALTER COLUMN id SET DEFAULT nextval('public.organization_branding_id_seq'::regclass);


--
-- Name: organizations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations ALTER COLUMN id SET DEFAULT nextval('public.organizations_id_seq'::regclass);


--
-- Name: pal_quiz_scores id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pal_quiz_scores ALTER COLUMN id SET DEFAULT nextval('public.pal_quiz_scores_id_seq'::regclass);


--
-- Name: pal_recommendations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pal_recommendations ALTER COLUMN id SET DEFAULT nextval('public.pal_recommendations_id_seq'::regclass);


--
-- Name: pal_topic_performance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pal_topic_performance ALTER COLUMN id SET DEFAULT nextval('public.pal_topic_performance_id_seq'::regclass);


--
-- Name: password_reset_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens ALTER COLUMN id SET DEFAULT nextval('public.password_reset_tokens_id_seq'::regclass);


--
-- Name: platform_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_settings ALTER COLUMN id SET DEFAULT nextval('public.platform_settings_id_seq'::regclass);


--
-- Name: question_banks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_banks ALTER COLUMN id SET DEFAULT nextval('public.question_banks_id_seq'::regclass);


--
-- Name: question_versions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_versions ALTER COLUMN id SET DEFAULT nextval('public.question_versions_id_seq'::regclass);


--
-- Name: questions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions ALTER COLUMN id SET DEFAULT nextval('public.questions_id_seq'::regclass);


--
-- Name: quiz_answers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_answers ALTER COLUMN id SET DEFAULT nextval('public.quiz_answers_id_seq'::regclass);


--
-- Name: quiz_attempt_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempt_events ALTER COLUMN id SET DEFAULT nextval('public.quiz_attempt_events_id_seq'::regclass);


--
-- Name: quiz_attempt_questions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempt_questions ALTER COLUMN id SET DEFAULT nextval('public.quiz_attempt_questions_id_seq'::regclass);


--
-- Name: quiz_attempts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempts ALTER COLUMN id SET DEFAULT nextval('public.quiz_attempts_id_seq'::regclass);


--
-- Name: quiz_definitions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_definitions ALTER COLUMN id SET DEFAULT nextval('public.quiz_definitions_id_seq'::regclass);


--
-- Name: quiz_questions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_questions ALTER COLUMN id SET DEFAULT nextval('public.quiz_questions_id_seq'::regclass);


--
-- Name: quiz_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_settings ALTER COLUMN id SET DEFAULT nextval('public.quiz_settings_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- Name: rubric_criteria id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rubric_criteria ALTER COLUMN id SET DEFAULT nextval('public.rubric_criteria_id_seq'::regclass);


--
-- Name: task_assignments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignments ALTER COLUMN id SET DEFAULT nextval('public.task_assignments_id_seq'::regclass);


--
-- Name: task_reviews id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_reviews ALTER COLUMN id SET DEFAULT nextval('public.task_reviews_id_seq'::regclass);


--
-- Name: task_submissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_submissions ALTER COLUMN id SET DEFAULT nextval('public.task_submissions_id_seq'::regclass);


--
-- Data for Name: activity_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_log (id, user_id, category_slug, icon, accent, message, created_at, updated_at, org_id) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
a5f009
\.


--
-- Data for Name: allowed_domains; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.allowed_domains (domain, label, added_by, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, actor_user_id, actor_name, action, target_type, target_id, message, accent, result, severity, ip_address, metadata_json, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auth_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_sessions (id, user_id, refresh_token, expires_at, revoked_at, created_at, updated_at, org_id, user_agent, ip_address) FROM stdin;
\.


--
-- Data for Name: builder_activity_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.builder_activity_log (id, course_id, user_id, action, payload, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, slug, description, status, accent_color, admin_user_id, planned_courses, avg_pal_target, moodle_category_id, org_type, archived_at, organization_id, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.certificates (id, user_id, course_id, issued_at, pdf_s3_key, certificate_hash, verification_token, qr_code_url, issued_version, metadata_json, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: course_edit_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.course_edit_locks (course_id, user_id, locked_at, expires_at, org_id) FROM stdin;
\.


--
-- Data for Name: course_modules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.course_modules (id, course_id, moodle_cmid, section, title, module_type, sort_order, content_url, org_id, created_at, updated_at, section_id, status, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: course_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.course_progress (id, user_id, course_id, status, completion_percentage, time_spent_seconds, started_at, last_viewed_at, completed_at, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: course_reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.course_reviews (id, course_id, action, from_status, to_status, notes, reviewed_by, reviewed_at, org_id) FROM stdin;
\.


--
-- Data for Name: course_sections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.course_sections (id, course_id, org_id, title, sort_order, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: course_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.course_versions (id, course_id, org_id, version_number, status, parent_version_id, created_by, published_at, published_by, created_at) FROM stdin;
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courses (id, moodle_course_id, category_slug, name, slug, description, tier, status, module_count, modules_json, lessons_count, hours, enrolled_count, completion_rate, completion_count, avg_quiz_score, prerequisite_course_id, org_id, created_at, updated_at, price_paise) FROM stdin;
\.


--
-- Data for Name: enrollment_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.enrollment_requests (id, full_name, email, category_slug, request_type, company_domain, domain_verified, status, requested_at, reviewed_by, reviewed_at, rejection_reason, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: grading_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grading_events (id, org_id, attempt_id, grader_id, previous_score, new_score, action, "timestamp") FROM stdin;
\.


--
-- Data for Name: grading_rubrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grading_rubrics (id, org_id, name) FROM stdin;
\.


--
-- Data for Name: interactive_tracking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.interactive_tracking (id, attempt_id, protocol, element, value, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: learner_activity_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.learner_activity_log (id, user_id, action, entity_type, entity_id, details, ip_address, created_at, org_id) FROM stdin;
\.


--
-- Data for Name: learner_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.learner_events (id, user_id, course_id, module_id, block_id, event_type, schema_version, payload_json, created_at, org_id) FROM stdin;
\.


--
-- Data for Name: learning_path_courses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.learning_path_courses (path_id, course_id, org_id, sort_order) FROM stdin;
\.


--
-- Data for Name: learning_path_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.learning_path_progress (id, user_id, path_id, status, completion_percentage, started_at, completed_at, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: learning_paths; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.learning_paths (id, org_id, title, description, settings, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: lesson_block_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lesson_block_progress (id, user_id, module_id, block_id, status, video_position_seconds, completion_percentage, time_spent_seconds, last_viewed_at, completed_at, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lesson_blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lesson_blocks (id, module_id, org_id, block_type, content, media_asset_id, sort_order, metadata_json, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: media_assets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media_assets (id, org_id, uploaded_by, file_name, file_type, file_size, storage_key, storage_provider, url, created_at, deleted_at, deleted_by, folder, tags_json, metadata_json) FROM stdin;
\.


--
-- Data for Name: memberships; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.memberships (id, user_id, org_id, role, category_scope, status, granted_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: module_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.module_progress (id, user_id, module_id, status, score, time_spent_seconds, completed_at, org_id, created_at, updated_at, last_block_id, started_at, last_viewed_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, user_id, title, body, type, is_read, metadata_json, created_at, updated_at, org_id) FROM stdin;
\.


--
-- Data for Name: org_invitations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_invitations (id, org_id, email, role, category_scope, token, invited_by, expires_at, accepted_at, revoked_at, revoked_by, revoke_reason, resend_count, last_sent_at, last_resent_at, delivery_status, delivery_error, delivery_attempted_at, delivered_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organization_branding; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organization_branding (id, org_id, organization_id, logo_url, favicon_url, login_banner_url, primary_color, secondary_color, font_family, theme_mode, certificate_template_url, email_template_id, landing_page_config, terminology_json, seo_title, seo_description, custom_domain, created_at, updated_at, certificate_primary_color, certificate_signature_url, certificate_qr_layout) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations (id, name, type, domain, slug, status, moodle_category_id, moodle_tenant_key, admin_user_id, created_by, created_at, updated_at, favicon_url, login_banner_url, primary_color, secondary_color, font_family, theme_mode, certificate_template, email_template, custom_domain, plan) FROM stdin;
\.


--
-- Data for Name: pal_quiz_scores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pal_quiz_scores (id, org_id, enrollment_number, user_id, course_id, course_name, quiz_id, quiz_name, topic, score, max_score, percentage, branch, college, synced_from_moodle, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pal_recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pal_recommendations (id, org_id, enrollment_number, user_id, level, weak_topics, strong_topics, recommended_courses, recommended_resources, avg_score, email_sent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pal_topic_performance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pal_topic_performance (id, org_id, enrollment_number, user_id, topic, avg_score, attempts, last_updated, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, used_at, delivery_status, delivery_error, delivery_attempted_at, delivered_at, created_at, updated_at, org_id) FROM stdin;
\.


--
-- Data for Name: pending_verifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pending_verifications (id, email, full_name, password_hash, role_name, domain_type, organization_name, organization_id, phone, employee_id, department, status, rejection_reason, reviewed_by, reviewed_at, moodle_id, program, branch, id_number, created_at, updated_at, org_id) FROM stdin;
\.


--
-- Data for Name: platform_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.platform_settings (id, setting_key, setting_value_json, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: question_banks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.question_banks (id, org_id, name, visibility, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: question_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.question_versions (id, question_id, version_number, question_type, question_text, options_json, correct_answer_json, points, metadata_json, created_at, org_id) FROM stdin;
\.


--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.questions (id, bank_id, org_id, current_version_id, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: quiz_answers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_answers (id, attempt_id, question_version_id, response_json, is_correct, points_awarded, instructor_feedback, org_id) FROM stdin;
\.


--
-- Data for Name: quiz_attempt_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_attempt_events (id, attempt_id, event_type, event_timestamp, metadata_json, org_id) FROM stdin;
\.


--
-- Data for Name: quiz_attempt_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_attempt_questions (id, attempt_id, question_version_id, display_order, org_id) FROM stdin;
\.


--
-- Data for Name: quiz_attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_attempts (id, org_id, quiz_id, user_id, status, started_at, submitted_at, total_score, passed, ip_address, user_agent, tab_switch_count) FROM stdin;
\.


--
-- Data for Name: quiz_definitions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_definitions (id, org_id, module_id, title, description, passing_score, created_at, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: quiz_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_questions (id, quiz_id, org_id, question_type, question_text, options_json, correct_answer_json, sort_order, points, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: quiz_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_settings (id, quiz_id, time_limit, passing_score, attempt_limit, show_answers, show_score, shuffle_questions, shuffle_options, cooldown_minutes, review_mode, created_at, org_id) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_permissions (id, org_id, role, permission_key, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rubric_criteria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rubric_criteria (id, rubric_id, name, max_points, org_id) FROM stdin;
\.


--
-- Data for Name: task_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_assignments (id, task_id, learner_id, status, assigned_at, started_at, submitted_at, completed_at, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_reviews (id, submission_id, review_status, review_notes, reviewed_by, reviewed_at, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_submissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_submissions (id, assignment_id, submission_notes, attachment_url, github_url, external_url, submitted_at, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, title, description, assigned_label, assigned_to_user_id, assignment_scope, category_slug, due_at, status, assigned_by, notes, is_cross_category, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, full_name, role, category_scope, password_hash, avatar_initials, gradient_start, gradient_end, is_active, is_platform_admin, status, pal_score, pal_completion_pct, pal_quiz_avg, pal_time_spent_hours, pal_task_completion_pct, streak_days, courses_completed, total_courses, cohort_rank, enrollment_type, current_course_id, course_progress_json, program, branch, id_number, moodle_id, last_login, invited_via, organization_id, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Name: activity_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_log_id_seq', 1, false);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: builder_activity_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.builder_activity_log_id_seq', 1, false);


--
-- Name: course_modules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.course_modules_id_seq', 1, false);


--
-- Name: course_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.course_progress_id_seq', 1, false);


--
-- Name: course_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.course_reviews_id_seq', 1, false);


--
-- Name: course_sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.course_sections_id_seq', 1, false);


--
-- Name: grading_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grading_events_id_seq', 1, false);


--
-- Name: grading_rubrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grading_rubrics_id_seq', 1, false);


--
-- Name: interactive_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.interactive_tracking_id_seq', 1, false);


--
-- Name: learner_activity_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.learner_activity_log_id_seq', 1, false);


--
-- Name: learner_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.learner_events_id_seq', 1, false);


--
-- Name: learning_path_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.learning_path_progress_id_seq', 1, false);


--
-- Name: learning_paths_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.learning_paths_id_seq', 1, false);


--
-- Name: lesson_block_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lesson_block_progress_id_seq', 1, false);


--
-- Name: lesson_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lesson_blocks_id_seq', 1, false);


--
-- Name: media_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.media_assets_id_seq', 1, false);


--
-- Name: memberships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.memberships_id_seq', 1, false);


--
-- Name: module_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.module_progress_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: org_invitations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.org_invitations_id_seq', 1, false);


--
-- Name: organization_branding_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organization_branding_id_seq', 1, false);


--
-- Name: organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizations_id_seq', 1, false);


--
-- Name: pal_quiz_scores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pal_quiz_scores_id_seq', 1, false);


--
-- Name: pal_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pal_recommendations_id_seq', 1, false);


--
-- Name: pal_topic_performance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pal_topic_performance_id_seq', 1, false);


--
-- Name: password_reset_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.password_reset_tokens_id_seq', 1, false);


--
-- Name: platform_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.platform_settings_id_seq', 1, false);


--
-- Name: question_banks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.question_banks_id_seq', 1, false);


--
-- Name: question_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.question_versions_id_seq', 1, false);


--
-- Name: questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.questions_id_seq', 1, false);


--
-- Name: quiz_answers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quiz_answers_id_seq', 1, false);


--
-- Name: quiz_attempt_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quiz_attempt_events_id_seq', 1, false);


--
-- Name: quiz_attempt_questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quiz_attempt_questions_id_seq', 1, false);


--
-- Name: quiz_attempts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quiz_attempts_id_seq', 1, false);


--
-- Name: quiz_definitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quiz_definitions_id_seq', 1, false);


--
-- Name: quiz_questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quiz_questions_id_seq', 1, false);


--
-- Name: quiz_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quiz_settings_id_seq', 1, false);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.role_permissions_id_seq', 1, false);


--
-- Name: rubric_criteria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rubric_criteria_id_seq', 1, false);


--
-- Name: task_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_assignments_id_seq', 1, false);


--
-- Name: task_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_reviews_id_seq', 1, false);


--
-- Name: task_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_submissions_id_seq', 1, false);


--
-- Name: activity_log activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: allowed_domains allowed_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.allowed_domains
    ADD CONSTRAINT allowed_domains_pkey PRIMARY KEY (domain);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (id);


--
-- Name: builder_activity_log builder_activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.builder_activity_log
    ADD CONSTRAINT builder_activity_log_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: course_edit_locks course_edit_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_edit_locks
    ADD CONSTRAINT course_edit_locks_pkey PRIMARY KEY (course_id);


--
-- Name: course_modules course_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_modules
    ADD CONSTRAINT course_modules_pkey PRIMARY KEY (id);


--
-- Name: course_progress course_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_progress
    ADD CONSTRAINT course_progress_pkey PRIMARY KEY (id);


--
-- Name: course_reviews course_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_reviews
    ADD CONSTRAINT course_reviews_pkey PRIMARY KEY (id);


--
-- Name: course_sections course_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_sections
    ADD CONSTRAINT course_sections_pkey PRIMARY KEY (id);


--
-- Name: course_versions course_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_versions
    ADD CONSTRAINT course_versions_pkey PRIMARY KEY (id);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: enrollment_requests enrollment_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollment_requests
    ADD CONSTRAINT enrollment_requests_pkey PRIMARY KEY (id);


--
-- Name: grading_events grading_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grading_events
    ADD CONSTRAINT grading_events_pkey PRIMARY KEY (id);


--
-- Name: grading_rubrics grading_rubrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grading_rubrics
    ADD CONSTRAINT grading_rubrics_pkey PRIMARY KEY (id);


--
-- Name: interactive_tracking interactive_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interactive_tracking
    ADD CONSTRAINT interactive_tracking_pkey PRIMARY KEY (id);


--
-- Name: learner_activity_log learner_activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learner_activity_log
    ADD CONSTRAINT learner_activity_log_pkey PRIMARY KEY (id);


--
-- Name: learner_events learner_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learner_events
    ADD CONSTRAINT learner_events_pkey PRIMARY KEY (id);


--
-- Name: learning_path_courses learning_path_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_path_courses
    ADD CONSTRAINT learning_path_courses_pkey PRIMARY KEY (path_id, course_id);


--
-- Name: learning_path_progress learning_path_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_path_progress
    ADD CONSTRAINT learning_path_progress_pkey PRIMARY KEY (id);


--
-- Name: learning_paths learning_paths_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_paths
    ADD CONSTRAINT learning_paths_pkey PRIMARY KEY (id);


--
-- Name: lesson_block_progress lesson_block_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_block_progress
    ADD CONSTRAINT lesson_block_progress_pkey PRIMARY KEY (id);


--
-- Name: lesson_blocks lesson_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_blocks
    ADD CONSTRAINT lesson_blocks_pkey PRIMARY KEY (id);


--
-- Name: media_assets media_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_pkey PRIMARY KEY (id);


--
-- Name: memberships memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT memberships_pkey PRIMARY KEY (id);


--
-- Name: module_progress module_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_progress
    ADD CONSTRAINT module_progress_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: org_invitations org_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT org_invitations_pkey PRIMARY KEY (id);


--
-- Name: organization_branding organization_branding_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_branding
    ADD CONSTRAINT organization_branding_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: pal_quiz_scores pal_quiz_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pal_quiz_scores
    ADD CONSTRAINT pal_quiz_scores_pkey PRIMARY KEY (id);


--
-- Name: pal_recommendations pal_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pal_recommendations
    ADD CONSTRAINT pal_recommendations_pkey PRIMARY KEY (id);


--
-- Name: pal_topic_performance pal_topic_performance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pal_topic_performance
    ADD CONSTRAINT pal_topic_performance_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: pending_verifications pending_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_verifications
    ADD CONSTRAINT pending_verifications_pkey PRIMARY KEY (id);


--
-- Name: platform_settings platform_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_pkey PRIMARY KEY (id);


--
-- Name: question_banks question_banks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_banks
    ADD CONSTRAINT question_banks_pkey PRIMARY KEY (id);


--
-- Name: question_versions question_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_versions
    ADD CONSTRAINT question_versions_pkey PRIMARY KEY (id);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: quiz_answers quiz_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_answers
    ADD CONSTRAINT quiz_answers_pkey PRIMARY KEY (id);


--
-- Name: quiz_attempt_events quiz_attempt_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempt_events
    ADD CONSTRAINT quiz_attempt_events_pkey PRIMARY KEY (id);


--
-- Name: quiz_attempt_questions quiz_attempt_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempt_questions
    ADD CONSTRAINT quiz_attempt_questions_pkey PRIMARY KEY (id);


--
-- Name: quiz_attempts quiz_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempts
    ADD CONSTRAINT quiz_attempts_pkey PRIMARY KEY (id);


--
-- Name: quiz_definitions quiz_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_definitions
    ADD CONSTRAINT quiz_definitions_pkey PRIMARY KEY (id);


--
-- Name: quiz_questions quiz_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_questions
    ADD CONSTRAINT quiz_questions_pkey PRIMARY KEY (id);


--
-- Name: quiz_settings quiz_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_settings
    ADD CONSTRAINT quiz_settings_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_org_id_role_permission_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_org_id_role_permission_key_key UNIQUE (org_id, role, permission_key);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: rubric_criteria rubric_criteria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rubric_criteria
    ADD CONSTRAINT rubric_criteria_pkey PRIMARY KEY (id);


--
-- Name: task_assignments task_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_pkey PRIMARY KEY (id);


--
-- Name: task_reviews task_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_reviews
    ADD CONSTRAINT task_reviews_pkey PRIMARY KEY (id);


--
-- Name: task_submissions task_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_submissions
    ADD CONSTRAINT task_submissions_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions uq_auth_sessions_refresh_token; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT uq_auth_sessions_refresh_token UNIQUE (refresh_token);


--
-- Name: categories uq_categories_slug; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT uq_categories_slug UNIQUE (slug);


--
-- Name: certificates uq_certificates_certificate_hash; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT uq_certificates_certificate_hash UNIQUE (certificate_hash);


--
-- Name: certificates uq_certificates_verification_token; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT uq_certificates_verification_token UNIQUE (verification_token);


--
-- Name: courses uq_courses_slug; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT uq_courses_slug UNIQUE (slug);


--
-- Name: memberships uq_membership_user_org; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT uq_membership_user_org UNIQUE (user_id, org_id);


--
-- Name: org_invitations uq_org_invitations_token; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT uq_org_invitations_token UNIQUE (token);


--
-- Name: organization_branding uq_organization_branding_organization_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_branding
    ADD CONSTRAINT uq_organization_branding_organization_id UNIQUE (organization_id);


--
-- Name: organizations uq_organizations_domain; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT uq_organizations_domain UNIQUE (domain);


--
-- Name: organizations uq_organizations_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT uq_organizations_name UNIQUE (name);


--
-- Name: organizations uq_organizations_slug; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT uq_organizations_slug UNIQUE (slug);


--
-- Name: pal_topic_performance uq_pal_topic_enrollment_org; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pal_topic_performance
    ADD CONSTRAINT uq_pal_topic_enrollment_org UNIQUE (enrollment_number, topic, org_id);


--
-- Name: password_reset_tokens uq_password_reset_tokens_token; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT uq_password_reset_tokens_token UNIQUE (token);


--
-- Name: pending_verifications uq_pending_verifications_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_verifications
    ADD CONSTRAINT uq_pending_verifications_email UNIQUE (email);


--
-- Name: platform_settings uq_platform_settings_setting_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT uq_platform_settings_setting_key UNIQUE (setting_key);


--
-- Name: task_assignments uq_task_assignments_task_learner; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT uq_task_assignments_task_learner UNIQUE (task_id, learner_id);


--
-- Name: users uq_users_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uq_users_email UNIQUE (email);


--
-- Name: users uq_users_username; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uq_users_username UNIQUE (username);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_org_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_org_time ON public.audit_log USING btree (org_id, created_at);


--
-- Name: idx_cats_org_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cats_org_status ON public.categories USING btree (organization_id, status);


--
-- Name: idx_courses_org_cat; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_courses_org_cat ON public.courses USING btree (org_id, category_slug);


--
-- Name: idx_enrol_org_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_enrol_org_status ON public.enrollment_requests USING btree (org_id, status);


--
-- Name: idx_invites_org_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invites_org_email ON public.org_invitations USING btree (org_id, email);


--
-- Name: idx_memberships_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_memberships_org ON public.memberships USING btree (org_id);


--
-- Name: idx_memberships_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_memberships_user ON public.memberships USING btree (user_id);


--
-- Name: idx_notif_user_read; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notif_user_read ON public.notifications USING btree (user_id, is_read);


--
-- Name: idx_pal_recs_org_enrol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pal_recs_org_enrol ON public.pal_recommendations USING btree (org_id, enrollment_number);


--
-- Name: idx_pal_scores_org_enrol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pal_scores_org_enrol ON public.pal_quiz_scores USING btree (org_id, enrollment_number);


--
-- Name: idx_pal_topics_org_enrol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pal_topics_org_enrol ON public.pal_topic_performance USING btree (org_id, enrollment_number);


--
-- Name: idx_sessions_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_user ON public.auth_sessions USING btree (user_id);


--
-- Name: idx_tasks_org_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tasks_org_user ON public.tasks USING btree (org_id, assigned_to_user_id);


--
-- Name: idx_users_org_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_org_active ON public.users USING btree (org_id, is_active);


--
-- Name: idx_users_org_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_org_role ON public.users USING btree (org_id, role);


--
-- Name: ix_activity_log_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_activity_log_user_id ON public.activity_log USING btree (user_id);


--
-- Name: ix_audit_log_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_action ON public.audit_log USING btree (action);


--
-- Name: ix_audit_log_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_org_id ON public.audit_log USING btree (org_id);


--
-- Name: ix_auth_sessions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_auth_sessions_user_id ON public.auth_sessions USING btree (user_id);


--
-- Name: ix_builder_activity_log_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_builder_activity_log_action ON public.builder_activity_log USING btree (action);


--
-- Name: ix_builder_activity_log_course_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_builder_activity_log_course_id ON public.builder_activity_log USING btree (course_id);


--
-- Name: ix_builder_activity_log_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_builder_activity_log_org_id ON public.builder_activity_log USING btree (org_id);


--
-- Name: ix_builder_activity_log_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_builder_activity_log_user_id ON public.builder_activity_log USING btree (user_id);


--
-- Name: ix_categories_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_categories_org_id ON public.categories USING btree (org_id);


--
-- Name: ix_categories_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_categories_slug ON public.categories USING btree (slug);


--
-- Name: ix_certificates_course_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_certificates_course_id ON public.certificates USING btree (course_id);


--
-- Name: ix_certificates_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_certificates_org_id ON public.certificates USING btree (org_id);


--
-- Name: ix_certificates_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_certificates_user_id ON public.certificates USING btree (user_id);


--
-- Name: ix_course_edit_locks_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_edit_locks_org_id ON public.course_edit_locks USING btree (org_id);


--
-- Name: ix_course_modules_course_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_modules_course_id ON public.course_modules USING btree (course_id);


--
-- Name: ix_course_modules_moodle_cmid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_modules_moodle_cmid ON public.course_modules USING btree (moodle_cmid);


--
-- Name: ix_course_modules_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_modules_org_id ON public.course_modules USING btree (org_id);


--
-- Name: ix_course_progress_course_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_progress_course_id ON public.course_progress USING btree (course_id);


--
-- Name: ix_course_progress_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_progress_org_id ON public.course_progress USING btree (org_id);


--
-- Name: ix_course_progress_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_progress_user_id ON public.course_progress USING btree (user_id);


--
-- Name: ix_course_reviews_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_reviews_action ON public.course_reviews USING btree (action);


--
-- Name: ix_course_reviews_course_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_reviews_course_id ON public.course_reviews USING btree (course_id);


--
-- Name: ix_course_reviews_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_reviews_org_id ON public.course_reviews USING btree (org_id);


--
-- Name: ix_course_reviews_reviewed_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_reviews_reviewed_by ON public.course_reviews USING btree (reviewed_by);


--
-- Name: ix_course_reviews_to_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_reviews_to_status ON public.course_reviews USING btree (to_status);


--
-- Name: ix_course_sections_course_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_sections_course_id ON public.course_sections USING btree (course_id);


--
-- Name: ix_course_sections_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_sections_id ON public.course_sections USING btree (id);


--
-- Name: ix_course_sections_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_sections_org_id ON public.course_sections USING btree (org_id);


--
-- Name: ix_course_versions_course_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_versions_course_id ON public.course_versions USING btree (course_id);


--
-- Name: ix_course_versions_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_versions_org_id ON public.course_versions USING btree (org_id);


--
-- Name: ix_course_versions_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_course_versions_status ON public.course_versions USING btree (status);


--
-- Name: ix_courses_category_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_courses_category_slug ON public.courses USING btree (category_slug);


--
-- Name: ix_courses_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_courses_org_id ON public.courses USING btree (org_id);


--
-- Name: ix_enrollment_requests_category_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_enrollment_requests_category_slug ON public.enrollment_requests USING btree (category_slug);


--
-- Name: ix_enrollment_requests_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_enrollment_requests_email ON public.enrollment_requests USING btree (email);


--
-- Name: ix_enrollment_requests_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_enrollment_requests_org_id ON public.enrollment_requests USING btree (org_id);


--
-- Name: ix_enrollment_requests_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_enrollment_requests_status ON public.enrollment_requests USING btree (status);


--
-- Name: ix_grading_events_attempt_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_grading_events_attempt_id ON public.grading_events USING btree (attempt_id);


--
-- Name: ix_grading_events_grader_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_grading_events_grader_id ON public.grading_events USING btree (grader_id);


--
-- Name: ix_grading_events_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_grading_events_id ON public.grading_events USING btree (id);


--
-- Name: ix_grading_events_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_grading_events_org_id ON public.grading_events USING btree (org_id);


--
-- Name: ix_grading_rubrics_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_grading_rubrics_id ON public.grading_rubrics USING btree (id);


--
-- Name: ix_grading_rubrics_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_grading_rubrics_org_id ON public.grading_rubrics USING btree (org_id);


--
-- Name: ix_interactive_tracking_attempt_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_interactive_tracking_attempt_id ON public.interactive_tracking USING btree (attempt_id);


--
-- Name: ix_interactive_tracking_element; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_interactive_tracking_element ON public.interactive_tracking USING btree (element);


--
-- Name: ix_interactive_tracking_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_interactive_tracking_org_id ON public.interactive_tracking USING btree (org_id);


--
-- Name: ix_learner_activity_log_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learner_activity_log_action ON public.learner_activity_log USING btree (action);


--
-- Name: ix_learner_activity_log_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learner_activity_log_org_id ON public.learner_activity_log USING btree (org_id);


--
-- Name: ix_learner_activity_log_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learner_activity_log_user_id ON public.learner_activity_log USING btree (user_id);


--
-- Name: ix_learner_events_block_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learner_events_block_id ON public.learner_events USING btree (block_id);


--
-- Name: ix_learner_events_course_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learner_events_course_id ON public.learner_events USING btree (course_id);


--
-- Name: ix_learner_events_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learner_events_event_type ON public.learner_events USING btree (event_type);


--
-- Name: ix_learner_events_module_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learner_events_module_id ON public.learner_events USING btree (module_id);


--
-- Name: ix_learner_events_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learner_events_org_id ON public.learner_events USING btree (org_id);


--
-- Name: ix_learner_events_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learner_events_user_id ON public.learner_events USING btree (user_id);


--
-- Name: ix_learning_path_courses_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learning_path_courses_org_id ON public.learning_path_courses USING btree (org_id);


--
-- Name: ix_learning_path_courses_path_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learning_path_courses_path_id ON public.learning_path_courses USING btree (path_id);


--
-- Name: ix_learning_path_progress_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learning_path_progress_org_id ON public.learning_path_progress USING btree (org_id);


--
-- Name: ix_learning_path_progress_path_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learning_path_progress_path_id ON public.learning_path_progress USING btree (path_id);


--
-- Name: ix_learning_path_progress_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learning_path_progress_user_id ON public.learning_path_progress USING btree (user_id);


--
-- Name: ix_learning_paths_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_learning_paths_org_id ON public.learning_paths USING btree (org_id);


--
-- Name: ix_lesson_block_progress_block_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_lesson_block_progress_block_id ON public.lesson_block_progress USING btree (block_id);


--
-- Name: ix_lesson_block_progress_module_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_lesson_block_progress_module_id ON public.lesson_block_progress USING btree (module_id);


--
-- Name: ix_lesson_block_progress_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_lesson_block_progress_org_id ON public.lesson_block_progress USING btree (org_id);


--
-- Name: ix_lesson_block_progress_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_lesson_block_progress_user_id ON public.lesson_block_progress USING btree (user_id);


--
-- Name: ix_lesson_blocks_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_lesson_blocks_id ON public.lesson_blocks USING btree (id);


--
-- Name: ix_lesson_blocks_module_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_lesson_blocks_module_id ON public.lesson_blocks USING btree (module_id);


--
-- Name: ix_lesson_blocks_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_lesson_blocks_org_id ON public.lesson_blocks USING btree (org_id);


--
-- Name: ix_media_assets_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_media_assets_id ON public.media_assets USING btree (id);


--
-- Name: ix_media_assets_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_media_assets_org_id ON public.media_assets USING btree (org_id);


--
-- Name: ix_module_progress_module_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_module_progress_module_id ON public.module_progress USING btree (module_id);


--
-- Name: ix_module_progress_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_module_progress_org_id ON public.module_progress USING btree (org_id);


--
-- Name: ix_module_progress_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_module_progress_user_id ON public.module_progress USING btree (user_id);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_organization_branding_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_organization_branding_org_id ON public.organization_branding USING btree (org_id);


--
-- Name: ix_pending_verifications_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_pending_verifications_org_id ON public.pending_verifications USING btree (org_id);


--
-- Name: ix_question_banks_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_question_banks_id ON public.question_banks USING btree (id);


--
-- Name: ix_question_banks_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_question_banks_org_id ON public.question_banks USING btree (org_id);


--
-- Name: ix_question_versions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_question_versions_id ON public.question_versions USING btree (id);


--
-- Name: ix_question_versions_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_question_versions_org_id ON public.question_versions USING btree (org_id);


--
-- Name: ix_question_versions_question_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_question_versions_question_id ON public.question_versions USING btree (question_id);


--
-- Name: ix_questions_bank_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_questions_bank_id ON public.questions USING btree (bank_id);


--
-- Name: ix_questions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_questions_id ON public.questions USING btree (id);


--
-- Name: ix_questions_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_questions_org_id ON public.questions USING btree (org_id);


--
-- Name: ix_quiz_answers_attempt_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_answers_attempt_id ON public.quiz_answers USING btree (attempt_id);


--
-- Name: ix_quiz_answers_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_answers_id ON public.quiz_answers USING btree (id);


--
-- Name: ix_quiz_answers_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_answers_org_id ON public.quiz_answers USING btree (org_id);


--
-- Name: ix_quiz_answers_question_version_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_answers_question_version_id ON public.quiz_answers USING btree (question_version_id);


--
-- Name: ix_quiz_attempt_events_attempt_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_attempt_events_attempt_id ON public.quiz_attempt_events USING btree (attempt_id);


--
-- Name: ix_quiz_attempt_events_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_attempt_events_id ON public.quiz_attempt_events USING btree (id);


--
-- Name: ix_quiz_attempt_events_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_attempt_events_org_id ON public.quiz_attempt_events USING btree (org_id);


--
-- Name: ix_quiz_attempt_questions_attempt_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_attempt_questions_attempt_id ON public.quiz_attempt_questions USING btree (attempt_id);


--
-- Name: ix_quiz_attempt_questions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_attempt_questions_id ON public.quiz_attempt_questions USING btree (id);


--
-- Name: ix_quiz_attempt_questions_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_attempt_questions_org_id ON public.quiz_attempt_questions USING btree (org_id);


--
-- Name: ix_quiz_attempt_questions_question_version_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_attempt_questions_question_version_id ON public.quiz_attempt_questions USING btree (question_version_id);


--
-- Name: ix_quiz_attempts_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_attempts_id ON public.quiz_attempts USING btree (id);


--
-- Name: ix_quiz_attempts_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_attempts_org_id ON public.quiz_attempts USING btree (org_id);


--
-- Name: ix_quiz_attempts_quiz_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_attempts_quiz_id ON public.quiz_attempts USING btree (quiz_id);


--
-- Name: ix_quiz_attempts_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_attempts_user_id ON public.quiz_attempts USING btree (user_id);


--
-- Name: ix_quiz_definitions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_definitions_id ON public.quiz_definitions USING btree (id);


--
-- Name: ix_quiz_definitions_module_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_definitions_module_id ON public.quiz_definitions USING btree (module_id);


--
-- Name: ix_quiz_definitions_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_definitions_org_id ON public.quiz_definitions USING btree (org_id);


--
-- Name: ix_quiz_questions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_questions_id ON public.quiz_questions USING btree (id);


--
-- Name: ix_quiz_questions_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_questions_org_id ON public.quiz_questions USING btree (org_id);


--
-- Name: ix_quiz_questions_quiz_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_questions_quiz_id ON public.quiz_questions USING btree (quiz_id);


--
-- Name: ix_quiz_settings_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_settings_id ON public.quiz_settings USING btree (id);


--
-- Name: ix_quiz_settings_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_quiz_settings_org_id ON public.quiz_settings USING btree (org_id);


--
-- Name: ix_quiz_settings_quiz_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_quiz_settings_quiz_id ON public.quiz_settings USING btree (quiz_id);


--
-- Name: ix_role_permissions_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_role_permissions_org_id ON public.role_permissions USING btree (org_id);


--
-- Name: ix_role_permissions_permission_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_role_permissions_permission_key ON public.role_permissions USING btree (permission_key);


--
-- Name: ix_role_permissions_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_role_permissions_role ON public.role_permissions USING btree (role);


--
-- Name: ix_rubric_criteria_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_rubric_criteria_id ON public.rubric_criteria USING btree (id);


--
-- Name: ix_rubric_criteria_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_rubric_criteria_org_id ON public.rubric_criteria USING btree (org_id);


--
-- Name: ix_rubric_criteria_rubric_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_rubric_criteria_rubric_id ON public.rubric_criteria USING btree (rubric_id);


--
-- Name: ix_task_assignments_learner_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_assignments_learner_id ON public.task_assignments USING btree (learner_id);


--
-- Name: ix_task_assignments_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_assignments_org_id ON public.task_assignments USING btree (org_id);


--
-- Name: ix_task_assignments_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_assignments_status ON public.task_assignments USING btree (status);


--
-- Name: ix_task_assignments_task_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_assignments_task_id ON public.task_assignments USING btree (task_id);


--
-- Name: ix_task_reviews_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_reviews_org_id ON public.task_reviews USING btree (org_id);


--
-- Name: ix_task_reviews_review_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_reviews_review_status ON public.task_reviews USING btree (review_status);


--
-- Name: ix_task_reviews_reviewed_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_reviews_reviewed_by ON public.task_reviews USING btree (reviewed_by);


--
-- Name: ix_task_reviews_submission_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_reviews_submission_id ON public.task_reviews USING btree (submission_id);


--
-- Name: ix_task_submissions_assignment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_submissions_assignment_id ON public.task_submissions USING btree (assignment_id);


--
-- Name: ix_task_submissions_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_task_submissions_org_id ON public.task_submissions USING btree (org_id);


--
-- Name: ix_tasks_assigned_to_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_assigned_to_user_id ON public.tasks USING btree (assigned_to_user_id);


--
-- Name: ix_tasks_category_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_category_slug ON public.tasks USING btree (category_slug);


--
-- Name: ix_tasks_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_org_id ON public.tasks USING btree (org_id);


--
-- Name: ix_tasks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_status ON public.tasks USING btree (status);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_org_id ON public.users USING btree (org_id);


--
-- Name: ix_users_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_role ON public.users USING btree (role);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: builder_activity_log builder_activity_log_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.builder_activity_log
    ADD CONSTRAINT builder_activity_log_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: course_edit_locks course_edit_locks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_edit_locks
    ADD CONSTRAINT course_edit_locks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: course_modules course_modules_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_modules
    ADD CONSTRAINT course_modules_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: course_modules course_modules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_modules
    ADD CONSTRAINT course_modules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: course_progress course_progress_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_progress
    ADD CONSTRAINT course_progress_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: course_progress course_progress_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_progress
    ADD CONSTRAINT course_progress_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: course_progress course_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_progress
    ADD CONSTRAINT course_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: course_reviews course_reviews_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_reviews
    ADD CONSTRAINT course_reviews_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: course_reviews course_reviews_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_reviews
    ADD CONSTRAINT course_reviews_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: course_reviews course_reviews_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_reviews
    ADD CONSTRAINT course_reviews_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: course_sections course_sections_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_sections
    ADD CONSTRAINT course_sections_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: course_sections course_sections_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_sections
    ADD CONSTRAINT course_sections_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: course_sections course_sections_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_sections
    ADD CONSTRAINT course_sections_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: course_versions course_versions_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_versions
    ADD CONSTRAINT course_versions_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: course_versions course_versions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_versions
    ADD CONSTRAINT course_versions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: course_versions course_versions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_versions
    ADD CONSTRAINT course_versions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: course_versions course_versions_parent_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_versions
    ADD CONSTRAINT course_versions_parent_version_id_fkey FOREIGN KEY (parent_version_id) REFERENCES public.course_versions(id);


--
-- Name: course_versions course_versions_published_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_versions
    ADD CONSTRAINT course_versions_published_by_fkey FOREIGN KEY (published_by) REFERENCES public.users(id);


--
-- Name: activity_log fk_activity_log_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT fk_activity_log_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: audit_log fk_audit_log_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT fk_audit_log_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: auth_sessions fk_auth_sessions_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT fk_auth_sessions_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: categories fk_categories_org; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fk_categories_org FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE SET NULL;


--
-- Name: categories fk_categories_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fk_categories_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: certificates fk_certificates_course_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT fk_certificates_course_id FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: certificates fk_certificates_org_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT fk_certificates_org_id FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: certificates fk_certificates_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT fk_certificates_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: course_modules fk_course_modules_deleted_by; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_modules
    ADD CONSTRAINT fk_course_modules_deleted_by FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: course_modules fk_course_modules_section_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_modules
    ADD CONSTRAINT fk_course_modules_section_id FOREIGN KEY (section_id) REFERENCES public.course_sections(id) ON DELETE SET NULL;


--
-- Name: courses fk_courses_org; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT fk_courses_org FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: courses fk_courses_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT fk_courses_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: enrollment_requests fk_enrollment_requests_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollment_requests
    ADD CONSTRAINT fk_enrollment_requests_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: enrollment_requests fk_enrollments_org; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollment_requests
    ADD CONSTRAINT fk_enrollments_org FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: interactive_tracking fk_interactive_tracking_attempt_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interactive_tracking
    ADD CONSTRAINT fk_interactive_tracking_attempt_id FOREIGN KEY (attempt_id) REFERENCES public.module_progress(id) ON DELETE CASCADE;


--
-- Name: interactive_tracking fk_interactive_tracking_org_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interactive_tracking
    ADD CONSTRAINT fk_interactive_tracking_org_id FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: notifications fk_notifications_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_notifications_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: org_invitations fk_org_invitations_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_invitations
    ADD CONSTRAINT fk_org_invitations_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_branding fk_organization_branding_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_branding
    ADD CONSTRAINT fk_organization_branding_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_branding fk_organization_branding_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organization_branding
    ADD CONSTRAINT fk_organization_branding_organization_id FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: pal_quiz_scores fk_pal_quiz_scores_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pal_quiz_scores
    ADD CONSTRAINT fk_pal_quiz_scores_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: pal_recommendations fk_pal_recommendations_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pal_recommendations
    ADD CONSTRAINT fk_pal_recommendations_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: pal_topic_performance fk_pal_topic_performance_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pal_topic_performance
    ADD CONSTRAINT fk_pal_topic_performance_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens fk_password_reset_tokens_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT fk_password_reset_tokens_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: pending_verifications fk_pending_verifications_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pending_verifications
    ADD CONSTRAINT fk_pending_verifications_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens fk_prt_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT fk_prt_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: question_versions fk_question_versions_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_versions
    ADD CONSTRAINT fk_question_versions_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: quiz_answers fk_quiz_answers_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_answers
    ADD CONSTRAINT fk_quiz_answers_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: quiz_settings fk_quiz_settings_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_settings
    ADD CONSTRAINT fk_quiz_settings_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: role_permissions fk_role_permissions_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT fk_role_permissions_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: rubric_criteria fk_rubric_criteria_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rubric_criteria
    ADD CONSTRAINT fk_rubric_criteria_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: auth_sessions fk_sessions_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tasks fk_tasks_org; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_org FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: tasks fk_tasks_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: users fk_users_org; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_org FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: users fk_users_org_id_organizations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_org_id_organizations FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: grading_events grading_events_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grading_events
    ADD CONSTRAINT grading_events_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES public.quiz_attempts(id);


--
-- Name: grading_events grading_events_grader_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grading_events
    ADD CONSTRAINT grading_events_grader_id_fkey FOREIGN KEY (grader_id) REFERENCES public.users(id);


--
-- Name: grading_events grading_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grading_events
    ADD CONSTRAINT grading_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: grading_rubrics grading_rubrics_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grading_rubrics
    ADD CONSTRAINT grading_rubrics_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: learner_activity_log learner_activity_log_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learner_activity_log
    ADD CONSTRAINT learner_activity_log_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: learner_activity_log learner_activity_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learner_activity_log
    ADD CONSTRAINT learner_activity_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: learner_events learner_events_block_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learner_events
    ADD CONSTRAINT learner_events_block_id_fkey FOREIGN KEY (block_id) REFERENCES public.lesson_blocks(id) ON DELETE CASCADE;


--
-- Name: learner_events learner_events_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learner_events
    ADD CONSTRAINT learner_events_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: learner_events learner_events_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learner_events
    ADD CONSTRAINT learner_events_module_id_fkey FOREIGN KEY (module_id) REFERENCES public.course_modules(id) ON DELETE CASCADE;


--
-- Name: learner_events learner_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learner_events
    ADD CONSTRAINT learner_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: learner_events learner_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learner_events
    ADD CONSTRAINT learner_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: learning_path_courses learning_path_courses_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_path_courses
    ADD CONSTRAINT learning_path_courses_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: learning_path_courses learning_path_courses_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_path_courses
    ADD CONSTRAINT learning_path_courses_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: learning_path_courses learning_path_courses_path_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_path_courses
    ADD CONSTRAINT learning_path_courses_path_id_fkey FOREIGN KEY (path_id) REFERENCES public.learning_paths(id);


--
-- Name: learning_path_progress learning_path_progress_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_path_progress
    ADD CONSTRAINT learning_path_progress_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: learning_path_progress learning_path_progress_path_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_path_progress
    ADD CONSTRAINT learning_path_progress_path_id_fkey FOREIGN KEY (path_id) REFERENCES public.learning_paths(id) ON DELETE CASCADE;


--
-- Name: learning_path_progress learning_path_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_path_progress
    ADD CONSTRAINT learning_path_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: learning_paths learning_paths_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_paths
    ADD CONSTRAINT learning_paths_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: learning_paths learning_paths_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.learning_paths
    ADD CONSTRAINT learning_paths_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: lesson_block_progress lesson_block_progress_block_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_block_progress
    ADD CONSTRAINT lesson_block_progress_block_id_fkey FOREIGN KEY (block_id) REFERENCES public.lesson_blocks(id) ON DELETE CASCADE;


--
-- Name: lesson_block_progress lesson_block_progress_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_block_progress
    ADD CONSTRAINT lesson_block_progress_module_id_fkey FOREIGN KEY (module_id) REFERENCES public.course_modules(id) ON DELETE CASCADE;


--
-- Name: lesson_block_progress lesson_block_progress_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_block_progress
    ADD CONSTRAINT lesson_block_progress_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: lesson_block_progress lesson_block_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_block_progress
    ADD CONSTRAINT lesson_block_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lesson_blocks lesson_blocks_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_blocks
    ADD CONSTRAINT lesson_blocks_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: lesson_blocks lesson_blocks_media_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_blocks
    ADD CONSTRAINT lesson_blocks_media_asset_id_fkey FOREIGN KEY (media_asset_id) REFERENCES public.media_assets(id);


--
-- Name: lesson_blocks lesson_blocks_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_blocks
    ADD CONSTRAINT lesson_blocks_module_id_fkey FOREIGN KEY (module_id) REFERENCES public.course_modules(id);


--
-- Name: lesson_blocks lesson_blocks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lesson_blocks
    ADD CONSTRAINT lesson_blocks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: media_assets media_assets_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: media_assets media_assets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: media_assets media_assets_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_assets
    ADD CONSTRAINT media_assets_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: memberships memberships_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT memberships_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: memberships memberships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT memberships_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: module_progress module_progress_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_progress
    ADD CONSTRAINT module_progress_module_id_fkey FOREIGN KEY (module_id) REFERENCES public.course_modules(id) ON DELETE CASCADE;


--
-- Name: module_progress module_progress_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_progress
    ADD CONSTRAINT module_progress_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: module_progress module_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.module_progress
    ADD CONSTRAINT module_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: question_banks question_banks_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_banks
    ADD CONSTRAINT question_banks_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: question_banks question_banks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_banks
    ADD CONSTRAINT question_banks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: question_versions question_versions_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question_versions
    ADD CONSTRAINT question_versions_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id);


--
-- Name: questions questions_bank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_bank_id_fkey FOREIGN KEY (bank_id) REFERENCES public.question_banks(id);


--
-- Name: questions questions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: quiz_answers quiz_answers_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_answers
    ADD CONSTRAINT quiz_answers_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES public.quiz_attempts(id);


--
-- Name: quiz_answers quiz_answers_question_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_answers
    ADD CONSTRAINT quiz_answers_question_version_id_fkey FOREIGN KEY (question_version_id) REFERENCES public.question_versions(id);


--
-- Name: quiz_attempt_events quiz_attempt_events_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempt_events
    ADD CONSTRAINT quiz_attempt_events_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES public.quiz_attempts(id);


--
-- Name: quiz_attempt_events quiz_attempt_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempt_events
    ADD CONSTRAINT quiz_attempt_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: quiz_attempt_questions quiz_attempt_questions_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempt_questions
    ADD CONSTRAINT quiz_attempt_questions_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES public.quiz_attempts(id);


--
-- Name: quiz_attempt_questions quiz_attempt_questions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempt_questions
    ADD CONSTRAINT quiz_attempt_questions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: quiz_attempt_questions quiz_attempt_questions_question_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempt_questions
    ADD CONSTRAINT quiz_attempt_questions_question_version_id_fkey FOREIGN KEY (question_version_id) REFERENCES public.question_versions(id);


--
-- Name: quiz_attempts quiz_attempts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempts
    ADD CONSTRAINT quiz_attempts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: quiz_attempts quiz_attempts_quiz_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempts
    ADD CONSTRAINT quiz_attempts_quiz_id_fkey FOREIGN KEY (quiz_id) REFERENCES public.quiz_definitions(id);


--
-- Name: quiz_attempts quiz_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_attempts
    ADD CONSTRAINT quiz_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: quiz_definitions quiz_definitions_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_definitions
    ADD CONSTRAINT quiz_definitions_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: quiz_definitions quiz_definitions_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_definitions
    ADD CONSTRAINT quiz_definitions_module_id_fkey FOREIGN KEY (module_id) REFERENCES public.course_modules(id);


--
-- Name: quiz_definitions quiz_definitions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_definitions
    ADD CONSTRAINT quiz_definitions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: quiz_questions quiz_questions_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_questions
    ADD CONSTRAINT quiz_questions_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: quiz_questions quiz_questions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_questions
    ADD CONSTRAINT quiz_questions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: quiz_questions quiz_questions_quiz_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_questions
    ADD CONSTRAINT quiz_questions_quiz_id_fkey FOREIGN KEY (quiz_id) REFERENCES public.quiz_definitions(id);


--
-- Name: quiz_settings quiz_settings_quiz_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_settings
    ADD CONSTRAINT quiz_settings_quiz_id_fkey FOREIGN KEY (quiz_id) REFERENCES public.quiz_definitions(id);


--
-- Name: role_permissions role_permissions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: rubric_criteria rubric_criteria_rubric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rubric_criteria
    ADD CONSTRAINT rubric_criteria_rubric_id_fkey FOREIGN KEY (rubric_id) REFERENCES public.grading_rubrics(id);


--
-- Name: task_assignments task_assignments_learner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_learner_id_fkey FOREIGN KEY (learner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_assignments task_assignments_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: task_assignments task_assignments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_assignments
    ADD CONSTRAINT task_assignments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_reviews task_reviews_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_reviews
    ADD CONSTRAINT task_reviews_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: task_reviews task_reviews_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_reviews
    ADD CONSTRAINT task_reviews_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: task_reviews task_reviews_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_reviews
    ADD CONSTRAINT task_reviews_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES public.task_submissions(id) ON DELETE CASCADE;


--
-- Name: task_submissions task_submissions_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_submissions
    ADD CONSTRAINT task_submissions_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.task_assignments(id) ON DELETE CASCADE;


--
-- Name: task_submissions task_submissions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_submissions
    ADD CONSTRAINT task_submissions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: activity_log; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.activity_log ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: auth_sessions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: builder_activity_log; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.builder_activity_log ENABLE ROW LEVEL SECURITY;

--
-- Name: categories; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

--
-- Name: course_edit_locks; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.course_edit_locks ENABLE ROW LEVEL SECURITY;

--
-- Name: course_modules; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.course_modules ENABLE ROW LEVEL SECURITY;

--
-- Name: course_progress; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.course_progress ENABLE ROW LEVEL SECURITY;

--
-- Name: course_reviews; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.course_reviews ENABLE ROW LEVEL SECURITY;

--
-- Name: course_sections; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.course_sections ENABLE ROW LEVEL SECURITY;

--
-- Name: course_versions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.course_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: courses; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;

--
-- Name: enrollment_requests; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.enrollment_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: grading_events; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.grading_events ENABLE ROW LEVEL SECURITY;

--
-- Name: grading_rubrics; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.grading_rubrics ENABLE ROW LEVEL SECURITY;

--
-- Name: interactive_tracking; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.interactive_tracking ENABLE ROW LEVEL SECURITY;

--
-- Name: learner_activity_log; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.learner_activity_log ENABLE ROW LEVEL SECURITY;

--
-- Name: learner_events; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.learner_events ENABLE ROW LEVEL SECURITY;

--
-- Name: learning_path_courses; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.learning_path_courses ENABLE ROW LEVEL SECURITY;

--
-- Name: learning_path_progress; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.learning_path_progress ENABLE ROW LEVEL SECURITY;

--
-- Name: learning_paths; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.learning_paths ENABLE ROW LEVEL SECURITY;

--
-- Name: lesson_block_progress; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.lesson_block_progress ENABLE ROW LEVEL SECURITY;

--
-- Name: lesson_blocks; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.lesson_blocks ENABLE ROW LEVEL SECURITY;

--
-- Name: media_assets; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.media_assets ENABLE ROW LEVEL SECURITY;

--
-- Name: memberships; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.memberships ENABLE ROW LEVEL SECURITY;

--
-- Name: module_progress; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.module_progress ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: org_invitations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.org_invitations ENABLE ROW LEVEL SECURITY;

--
-- Name: organization_branding; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.organization_branding ENABLE ROW LEVEL SECURITY;

--
-- Name: pal_quiz_scores; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.pal_quiz_scores ENABLE ROW LEVEL SECURITY;

--
-- Name: pal_recommendations; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.pal_recommendations ENABLE ROW LEVEL SECURITY;

--
-- Name: pal_topic_performance; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.pal_topic_performance ENABLE ROW LEVEL SECURITY;

--
-- Name: password_reset_tokens; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.password_reset_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: pending_verifications; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.pending_verifications ENABLE ROW LEVEL SECURITY;

--
-- Name: question_banks; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.question_banks ENABLE ROW LEVEL SECURITY;

--
-- Name: question_versions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.question_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: questions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;

--
-- Name: quiz_answers; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quiz_answers ENABLE ROW LEVEL SECURITY;

--
-- Name: quiz_attempt_events; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quiz_attempt_events ENABLE ROW LEVEL SECURITY;

--
-- Name: quiz_attempt_questions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quiz_attempt_questions ENABLE ROW LEVEL SECURITY;

--
-- Name: quiz_attempts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quiz_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: quiz_definitions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quiz_definitions ENABLE ROW LEVEL SECURITY;

--
-- Name: quiz_settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quiz_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: role_permissions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;

--
-- Name: rubric_criteria; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.rubric_criteria ENABLE ROW LEVEL SECURITY;

--
-- Name: task_assignments; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.task_assignments ENABLE ROW LEVEL SECURITY;

--
-- Name: task_assignments task_assignments_tenant_isolation; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY task_assignments_tenant_isolation ON public.task_assignments USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: task_reviews; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.task_reviews ENABLE ROW LEVEL SECURITY;

--
-- Name: task_reviews task_reviews_tenant_isolation; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY task_reviews_tenant_isolation ON public.task_reviews USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: task_submissions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.task_submissions ENABLE ROW LEVEL SECURITY;

--
-- Name: task_submissions task_submissions_tenant_isolation; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY task_submissions_tenant_isolation ON public.task_submissions USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: tasks; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_log telite_tenant_isolation_activity_log; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_activity_log ON public.activity_log USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: audit_log telite_tenant_isolation_audit_log; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_audit_log ON public.audit_log USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: auth_sessions telite_tenant_isolation_auth_sessions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_auth_sessions ON public.auth_sessions USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: builder_activity_log telite_tenant_isolation_builder_activity_log; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_builder_activity_log ON public.builder_activity_log USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: categories telite_tenant_isolation_categories; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_categories ON public.categories USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: course_edit_locks telite_tenant_isolation_course_edit_locks; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_course_edit_locks ON public.course_edit_locks USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: course_modules telite_tenant_isolation_course_modules; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_course_modules ON public.course_modules USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: course_progress telite_tenant_isolation_course_progress; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_course_progress ON public.course_progress USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: course_reviews telite_tenant_isolation_course_reviews; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_course_reviews ON public.course_reviews USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: course_sections telite_tenant_isolation_course_sections; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_course_sections ON public.course_sections USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: course_versions telite_tenant_isolation_course_versions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_course_versions ON public.course_versions USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: courses telite_tenant_isolation_courses; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_courses ON public.courses USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: enrollment_requests telite_tenant_isolation_enrollment_requests; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_enrollment_requests ON public.enrollment_requests USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: grading_events telite_tenant_isolation_grading_events; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_grading_events ON public.grading_events USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: grading_rubrics telite_tenant_isolation_grading_rubrics; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_grading_rubrics ON public.grading_rubrics USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: interactive_tracking telite_tenant_isolation_interactive_tracking; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_interactive_tracking ON public.interactive_tracking USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: learner_activity_log telite_tenant_isolation_learner_activity_log; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_learner_activity_log ON public.learner_activity_log USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: learner_events telite_tenant_isolation_learner_events; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_learner_events ON public.learner_events USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: learning_path_courses telite_tenant_isolation_learning_path_courses; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_learning_path_courses ON public.learning_path_courses USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: learning_path_progress telite_tenant_isolation_learning_path_progress; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_learning_path_progress ON public.learning_path_progress USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: learning_paths telite_tenant_isolation_learning_paths; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_learning_paths ON public.learning_paths USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: lesson_block_progress telite_tenant_isolation_lesson_block_progress; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_lesson_block_progress ON public.lesson_block_progress USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: lesson_blocks telite_tenant_isolation_lesson_blocks; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_lesson_blocks ON public.lesson_blocks USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: media_assets telite_tenant_isolation_media_assets; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_media_assets ON public.media_assets USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: memberships telite_tenant_isolation_memberships; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_memberships ON public.memberships USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: module_progress telite_tenant_isolation_module_progress; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_module_progress ON public.module_progress USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: notifications telite_tenant_isolation_notifications; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_notifications ON public.notifications USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: org_invitations telite_tenant_isolation_org_invitations; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_org_invitations ON public.org_invitations USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: organization_branding telite_tenant_isolation_organization_branding; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_organization_branding ON public.organization_branding USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: pal_quiz_scores telite_tenant_isolation_pal_quiz_scores; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_pal_quiz_scores ON public.pal_quiz_scores USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: pal_recommendations telite_tenant_isolation_pal_recommendations; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_pal_recommendations ON public.pal_recommendations USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: pal_topic_performance telite_tenant_isolation_pal_topic_performance; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_pal_topic_performance ON public.pal_topic_performance USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: password_reset_tokens telite_tenant_isolation_password_reset_tokens; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_password_reset_tokens ON public.password_reset_tokens USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: pending_verifications telite_tenant_isolation_pending_verifications; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_pending_verifications ON public.pending_verifications USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: question_banks telite_tenant_isolation_question_banks; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_question_banks ON public.question_banks USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: question_versions telite_tenant_isolation_question_versions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_question_versions ON public.question_versions USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: questions telite_tenant_isolation_questions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_questions ON public.questions USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: quiz_answers telite_tenant_isolation_quiz_answers; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_quiz_answers ON public.quiz_answers USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: quiz_attempt_events telite_tenant_isolation_quiz_attempt_events; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_quiz_attempt_events ON public.quiz_attempt_events USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: quiz_attempt_questions telite_tenant_isolation_quiz_attempt_questions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_quiz_attempt_questions ON public.quiz_attempt_questions USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: quiz_attempts telite_tenant_isolation_quiz_attempts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_quiz_attempts ON public.quiz_attempts USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: quiz_definitions telite_tenant_isolation_quiz_definitions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_quiz_definitions ON public.quiz_definitions USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: quiz_settings telite_tenant_isolation_quiz_settings; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_quiz_settings ON public.quiz_settings USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: role_permissions telite_tenant_isolation_role_permissions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_role_permissions ON public.role_permissions USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: rubric_criteria telite_tenant_isolation_rubric_criteria; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_rubric_criteria ON public.rubric_criteria USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: tasks telite_tenant_isolation_tasks; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_tasks ON public.tasks USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: users telite_tenant_isolation_users; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY telite_tenant_isolation_users ON public.users USING (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer))) WITH CHECK (((current_setting('app.bypass_rls'::text, true) = 'on'::text) OR (org_id = (NULLIF(current_setting('app.current_org_id'::text, true), ''::text))::integer)));


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: DATABASE telite_backend; Type: ACL; Schema: -; Owner: telite_app
--

REVOKE CONNECT,TEMPORARY ON DATABASE telite_backend FROM PUBLIC;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO telite_app;


--
-- Name: TABLE activity_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.activity_log TO telite_app;


--
-- Name: SEQUENCE activity_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.activity_log_id_seq TO telite_app;


--
-- Name: TABLE alembic_version; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.alembic_version TO telite_app;


--
-- Name: TABLE allowed_domains; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.allowed_domains TO telite_app;


--
-- Name: TABLE audit_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.audit_log TO telite_app;


--
-- Name: SEQUENCE audit_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.audit_log_id_seq TO telite_app;


--
-- Name: TABLE auth_sessions; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.auth_sessions TO telite_app;


--
-- Name: TABLE builder_activity_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.builder_activity_log TO telite_app;


--
-- Name: SEQUENCE builder_activity_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.builder_activity_log_id_seq TO telite_app;


--
-- Name: TABLE categories; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.categories TO telite_app;


--
-- Name: TABLE certificates; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.certificates TO telite_app;


--
-- Name: TABLE course_edit_locks; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.course_edit_locks TO telite_app;


--
-- Name: TABLE course_modules; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.course_modules TO telite_app;


--
-- Name: SEQUENCE course_modules_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.course_modules_id_seq TO telite_app;


--
-- Name: TABLE course_progress; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.course_progress TO telite_app;


--
-- Name: SEQUENCE course_progress_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.course_progress_id_seq TO telite_app;


--
-- Name: TABLE course_reviews; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.course_reviews TO telite_app;


--
-- Name: SEQUENCE course_reviews_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.course_reviews_id_seq TO telite_app;


--
-- Name: TABLE course_sections; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.course_sections TO telite_app;


--
-- Name: SEQUENCE course_sections_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.course_sections_id_seq TO telite_app;


--
-- Name: TABLE course_versions; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.course_versions TO telite_app;


--
-- Name: TABLE courses; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.courses TO telite_app;


--
-- Name: TABLE enrollment_requests; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.enrollment_requests TO telite_app;


--
-- Name: TABLE grading_events; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.grading_events TO telite_app;


--
-- Name: SEQUENCE grading_events_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.grading_events_id_seq TO telite_app;


--
-- Name: TABLE grading_rubrics; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.grading_rubrics TO telite_app;


--
-- Name: SEQUENCE grading_rubrics_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.grading_rubrics_id_seq TO telite_app;


--
-- Name: TABLE interactive_tracking; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.interactive_tracking TO telite_app;


--
-- Name: SEQUENCE interactive_tracking_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.interactive_tracking_id_seq TO telite_app;


--
-- Name: TABLE learner_activity_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.learner_activity_log TO telite_app;


--
-- Name: SEQUENCE learner_activity_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.learner_activity_log_id_seq TO telite_app;


--
-- Name: TABLE learner_events; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.learner_events TO telite_app;


--
-- Name: SEQUENCE learner_events_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.learner_events_id_seq TO telite_app;


--
-- Name: TABLE learning_path_courses; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.learning_path_courses TO telite_app;


--
-- Name: TABLE learning_path_progress; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.learning_path_progress TO telite_app;


--
-- Name: SEQUENCE learning_path_progress_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.learning_path_progress_id_seq TO telite_app;


--
-- Name: TABLE learning_paths; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.learning_paths TO telite_app;


--
-- Name: SEQUENCE learning_paths_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.learning_paths_id_seq TO telite_app;


--
-- Name: TABLE lesson_block_progress; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lesson_block_progress TO telite_app;


--
-- Name: SEQUENCE lesson_block_progress_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.lesson_block_progress_id_seq TO telite_app;


--
-- Name: TABLE lesson_blocks; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.lesson_blocks TO telite_app;


--
-- Name: SEQUENCE lesson_blocks_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.lesson_blocks_id_seq TO telite_app;


--
-- Name: TABLE media_assets; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.media_assets TO telite_app;


--
-- Name: SEQUENCE media_assets_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.media_assets_id_seq TO telite_app;


--
-- Name: TABLE memberships; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.memberships TO telite_app;


--
-- Name: SEQUENCE memberships_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.memberships_id_seq TO telite_app;


--
-- Name: TABLE module_progress; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.module_progress TO telite_app;


--
-- Name: SEQUENCE module_progress_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.module_progress_id_seq TO telite_app;


--
-- Name: TABLE notifications; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.notifications TO telite_app;


--
-- Name: SEQUENCE notifications_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.notifications_id_seq TO telite_app;


--
-- Name: TABLE org_invitations; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.org_invitations TO telite_app;


--
-- Name: SEQUENCE org_invitations_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.org_invitations_id_seq TO telite_app;


--
-- Name: TABLE organization_branding; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.organization_branding TO telite_app;


--
-- Name: SEQUENCE organization_branding_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.organization_branding_id_seq TO telite_app;


--
-- Name: TABLE organizations; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.organizations TO telite_app;


--
-- Name: SEQUENCE organizations_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.organizations_id_seq TO telite_app;


--
-- Name: TABLE pal_quiz_scores; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pal_quiz_scores TO telite_app;


--
-- Name: SEQUENCE pal_quiz_scores_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.pal_quiz_scores_id_seq TO telite_app;


--
-- Name: TABLE pal_recommendations; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pal_recommendations TO telite_app;


--
-- Name: SEQUENCE pal_recommendations_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.pal_recommendations_id_seq TO telite_app;


--
-- Name: TABLE pal_topic_performance; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pal_topic_performance TO telite_app;


--
-- Name: SEQUENCE pal_topic_performance_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.pal_topic_performance_id_seq TO telite_app;


--
-- Name: TABLE password_reset_tokens; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.password_reset_tokens TO telite_app;


--
-- Name: SEQUENCE password_reset_tokens_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.password_reset_tokens_id_seq TO telite_app;


--
-- Name: TABLE pending_verifications; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pending_verifications TO telite_app;


--
-- Name: TABLE platform_settings; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.platform_settings TO telite_app;


--
-- Name: SEQUENCE platform_settings_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.platform_settings_id_seq TO telite_app;


--
-- Name: TABLE question_banks; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.question_banks TO telite_app;


--
-- Name: SEQUENCE question_banks_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.question_banks_id_seq TO telite_app;


--
-- Name: TABLE question_versions; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.question_versions TO telite_app;


--
-- Name: SEQUENCE question_versions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.question_versions_id_seq TO telite_app;


--
-- Name: TABLE questions; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.questions TO telite_app;


--
-- Name: SEQUENCE questions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.questions_id_seq TO telite_app;


--
-- Name: TABLE quiz_answers; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.quiz_answers TO telite_app;


--
-- Name: SEQUENCE quiz_answers_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.quiz_answers_id_seq TO telite_app;


--
-- Name: TABLE quiz_attempt_events; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.quiz_attempt_events TO telite_app;


--
-- Name: SEQUENCE quiz_attempt_events_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.quiz_attempt_events_id_seq TO telite_app;


--
-- Name: TABLE quiz_attempt_questions; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.quiz_attempt_questions TO telite_app;


--
-- Name: SEQUENCE quiz_attempt_questions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.quiz_attempt_questions_id_seq TO telite_app;


--
-- Name: TABLE quiz_attempts; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.quiz_attempts TO telite_app;


--
-- Name: SEQUENCE quiz_attempts_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.quiz_attempts_id_seq TO telite_app;


--
-- Name: TABLE quiz_definitions; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.quiz_definitions TO telite_app;


--
-- Name: SEQUENCE quiz_definitions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.quiz_definitions_id_seq TO telite_app;


--
-- Name: TABLE quiz_questions; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.quiz_questions TO telite_app;


--
-- Name: SEQUENCE quiz_questions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.quiz_questions_id_seq TO telite_app;


--
-- Name: TABLE quiz_settings; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.quiz_settings TO telite_app;


--
-- Name: SEQUENCE quiz_settings_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.quiz_settings_id_seq TO telite_app;


--
-- Name: TABLE role_permissions; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.role_permissions TO telite_app;


--
-- Name: SEQUENCE role_permissions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.role_permissions_id_seq TO telite_app;


--
-- Name: TABLE rubric_criteria; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.rubric_criteria TO telite_app;


--
-- Name: SEQUENCE rubric_criteria_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.rubric_criteria_id_seq TO telite_app;


--
-- Name: TABLE task_assignments; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.task_assignments TO telite_app;


--
-- Name: SEQUENCE task_assignments_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.task_assignments_id_seq TO telite_app;


--
-- Name: TABLE task_reviews; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.task_reviews TO telite_app;


--
-- Name: SEQUENCE task_reviews_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.task_reviews_id_seq TO telite_app;


--
-- Name: TABLE task_submissions; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.task_submissions TO telite_app;


--
-- Name: SEQUENCE task_submissions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.task_submissions_id_seq TO telite_app;


--
-- Name: TABLE tasks; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tasks TO telite_app;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO telite_app;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES  TO telite_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES  TO telite_app;


--
-- PostgreSQL database dump complete
--

\unrestrict 0oecDhTThbgAG6NMz5fHYH6r7kh2ajFeT5NoosccTwtU1UjiQOOt8bDbvacrI3J

--
-- PostgreSQL database cluster dump complete
--

